"""TL1 three-method comparison (campaign3_20261120): shared infrastructure.  Frozen with PROTOCOL.md (see PROTOCOL.sha256).

* Trial store: one MOOSE observation per unique (oracle identity, signed direction) key, in trials/<key>/; index trials/index.jsonl (fcntl-locked
  append).  Exact-match reuse ONLY inside this campaign and ONLY for an identical key (direction rounded to 12 decimals, as the frozen _key;
  oracle identity = sha256 of the TL1 oracle code, calibration, mesh, constraint matrix, lattice, solver DEFAULTS).  TREF references and
  all earlier runs are never in the store.  A per-key lock file prevents two processes from running the same direction.
* CPU ledger cpu_ledger.jsonl (locked append): every MOOSE run, controller and evaluation CPU.  HARD CAP 8 CPU-h for the authorization
  (Stage 1 charged with an upper estimate).  Before every MOOSE launch: ledger + in-flight allowance + evaluation reserve <= cap, else CapReached.
* Guard: any combined-opt process whose working directory is not inside this campaign stops new launches (ForeignMoose).
* Nothing is ever deleted or overwritten.
"""
import fcntl, hashlib, json, os, sys, time
from contextlib import contextmanager
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent; T = HERE.parents[1]; CL = T.parent
for p in (str(T / "controller"), str(T / "oracle")):
    if p not in sys.path:
        sys.path.insert(0, p)
import truss_v2_compat as W                                                          # frozen V2 / V1 access + hash checks
import truss_oracle as TO                                                            # validated TL1 MOOSE oracle (V2 validation)
from yield_surface_discovery.oracle import YieldOracle, YieldObservation             # frozen V1

TRIALS = HERE / "trials"; INDEX = TRIALS / "index.jsonl"; LEDGER = HERE / "cpu_ledger.jsonl"
CAP_CPU_S = 8 * 3600.0; EVAL_RESERVE_S = 0.25 * 3600.0; INFLIGHT_S = 15.0
STARTS = tuple(range(9)); BUDGET = 64; N_INIT = 8; SPARES = 16; CHECKPOINTS = (8, 16, 33, 64)
METHODS = ("V2", "AXMM", "RANDOM")
LIB_CSV = T / "library/TLIB4096_v1.csv"; LIB_SHA = "b94b06cf119b6f85d15e0d8303d4c6406fe01172883d38c22f36414ca0c80908"
TREF_CSV = T / "pilot/refs_TREF_v1_20261120T171229/reference_results.csv"
CAL = json.loads((T / "oracle/calibration_TL1.json").read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
ORACLE_FILES = ["oracle/truss_oracle.py", "oracle/calibration_TL1.json", "oracle/mesh_TL1/mesh.e", "oracle/mesh_TL1/constraint_matrix.m", "lattice/TL1_frozen.json"]
ORACLE_ID = hashlib.sha256(json.dumps(dict({f: sha(T / f) for f in ORACLE_FILES}, defaults=TO.DEFAULTS), sort_keys=True).encode()).hexdigest()


class CapReached(RuntimeError):
    pass


class ForeignMoose(RuntimeError):
    pass


class NumericalInvalid(RuntimeError):
    pass


def library():
    assert sha(LIB_CSV) == LIB_SHA; return W.load_library(LIB_CSV)


def key(d):
    return tuple(np.round(np.asarray(d, float), 12))


def keyhash(d):
    return hashlib.sha256((ORACLE_ID + json.dumps([float(x) for x in key(d)])).encode()).hexdigest()[:16]


@contextmanager
def locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield fh
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def ledger_add(item, cpu_s, **kw):
    with locked(HERE / ".ledger.lock"):
        with open(LEDGER, "a") as f:
            f.write(json.dumps(dict(time=time.strftime("%Y-%m-%dT%H:%M:%S"), pid=os.getpid(), item=item, cpu_s=float(cpu_s), **kw)) + "\n")


def ledger_total():
    if not LEDGER.exists():
        return 0.0
    return sum(json.loads(l)["cpu_s"] for l in LEDGER.read_text().splitlines() if l.strip())


def foreign_moose():
    out = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            cmd = open(f"/proc/{pid}/cmdline", "rb").read().split(b"\0")
            if not cmd or not cmd[0].endswith(b"-opt"):
                continue
            cwd = os.readlink(f"/proc/{pid}/cwd")
        except OSError:
            continue
        if not cwd.startswith(str(TRIALS)):
            out.append((pid, cwd))
    return out


def index_lookup(d):
    """compact index (keyhash -> record file); full records in trials/records/<keyhash>.json."""
    k = keyhash(d)
    with locked(TRIALS / ".index.lock"):
        lines = INDEX.read_text().splitlines() if INDEX.exists() else []
    for l in lines:
        x = json.loads(l)
        if x["keyhash"] == k:
            return json.loads((HERE / x["record"]).read_text())
    return None


def valid(rec):
    """numerical-validity of an accepted record (V2 validation tolerances)."""
    return bool(rec.get("accepted") and rec.get("crossed") and rec["equilibrium_rel_err_max"] <= 1e-6 and rec["achieved_dir_err_deg"] <= 1e-3
                and rec["periodic_check"]["rel"] <= 1e-8 and rec["failed_steps"] == 0 and np.isfinite(rec["yield_radius"]) and rec["yield_radius"] > 0)


def get(d, requester):
    """return the store record for signed direction d (run MOOSE if absent).  Logs every request to requests.jsonl."""
    d = np.asarray(d, float) / np.linalg.norm(d); k = keyhash(d)
    with locked(TRIALS / "locks" / f"{k}.lock"):
        r = index_lookup(d); reused = r is not None
        if r is None:
            if foreign_moose():
                raise ForeignMoose(str(foreign_moose()[:3]))
            if ledger_total() + INFLIGHT_S * 8 + EVAL_RESERVE_S > CAP_CPU_S:
                raise CapReached(f"ledger {ledger_total() / 3600:.3f} CPU-h")
            wd = TRIALS / k
            if wd.exists():                                                          # interrupted earlier run: keep it, use a fresh suffix
                wd = TRIALS / f"{k}_retry{int(time.time())}"
            try:
                rec = TO.observe(d, wd, CAL)
            except Exception as e:                                                   # recorded as failed trial
                rec = dict(direction=list(d), accepted=False, reason=repr(e), cpu_s=0.0, wall_s=0.0, flags=["exception"])
            rec.update(keyhash=k, key=[float(x) for x in key(d)], oracle_id=ORACLE_ID, workdir=str(wd.relative_to(HERE)), first_requester=requester)
            rec["valid"] = valid(rec) if rec.get("accepted") else False
            rf = TRIALS / "records" / f"{k}.json"
            if rf.exists():                                                          # never overwrite: earlier interrupted attempt
                rf = TRIALS / "records" / f"{k}_retry{int(time.time())}.json"
            rf.parent.mkdir(parents=True, exist_ok=True); rf.write_text(json.dumps(rec, indent=1, default=float))
            ledger_add(f"moose:{k}", rec.get("cpu_s", 0.0), requester=requester)
            with locked(TRIALS / ".index.lock"):
                with open(INDEX, "a") as f:
                    f.write(json.dumps(dict(keyhash=k, record=str(rf.relative_to(HERE)), accepted=bool(rec.get("accepted")), valid=rec["valid"])) + "\n")
            r = rec
    with locked(HERE / ".requests.lock"):
        with open(HERE / "requests.jsonl", "a") as f:
            f.write(json.dumps(dict(time=time.time(), requester=requester, keyhash=k, reused=reused, accepted=bool(r.get("accepted")),
                                    valid=bool(r.get("valid")), yield_radius=r.get("yield_radius"))) + "\n")
    if r.get("accepted") and not r.get("valid"):
        raise NumericalInvalid(f"accepted record failed validity tolerances: {k}")
    return r


class C3Oracle(YieldOracle):
    """blind adapter for the frozen V2 controller: returns only the public observation."""

    def __init__(self, requester):
        self.requester = requester; self.calls = 0

    def _obs(self, d, r):
        ok = bool(r.get("accepted")) and r.get("valid")
        sm = np.asarray(r["stress_mandel"], float) if ok else np.full(3, np.nan)
        return YieldObservation(requested_direction=np.asarray(d, float), achieved_direction=sm / np.linalg.norm(sm) if ok else np.asarray(d, float),
                                yield_radius=float(r["yield_radius"]) if ok else float("nan"), stress_at_yield=sm * np.array([1, 1, 1 / np.sqrt(2)]) if ok else sm,
                                success=ok, status="ok" if ok else "rejected", metadata=dict(keyhash=r["keyhash"]))

    def evaluate(self, d):
        self.calls += 1; return self._obs(d, get(d, self.requester))

    def evaluate_many(self, X):
        return [self.evaluate(x) for x in np.atleast_2d(X)]


# ------------------------------------------------------------------ designs (response-independent parts)
def first_index(n, s):
    return W.first_index(n, s)


def initial_design(lib, s):
    """= frozen V2Controller(symmetry='none').initial_design(s) = angular maximin (SIGNED angle) from first(s), 8 points (asserted at use)."""
    return [int(c) for c in W.angular_maximin(lib.directions, first_index(len(lib.directions), s), N_INIT, "deterministic", 1e-9)]


def maximin_order(lib, s):
    """signed angular maximin (frozen V1 deterministic rule, atan2 angle) from first(s): BUDGET + SPARES candidates in greedy order."""
    return [int(c) for c in W.angular_maximin(lib.directions, first_index(len(lib.directions), s), BUDGET + SPARES, "deterministic", 1e-9)]


def random_order(lib, s):
    """initial 8, then numpy default_rng(9000 + s).permutation of all remaining signed candidates."""
    init = initial_design(lib, s); st = set(init)
    return init + [int(c) for c in np.random.default_rng(9000 + s).permutation(len(lib.directions)) if int(c) not in st]

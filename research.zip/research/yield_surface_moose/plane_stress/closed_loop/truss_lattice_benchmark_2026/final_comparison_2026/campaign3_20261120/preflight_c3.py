#!/usr/bin/env python3
"""Pre-launch verification (no MOOSE).  Writes preflight/preflight_<ts>.json.  Run: python -B preflight_c3.py
T1 frozen inputs  T2 references & leakage  T3 designs (signed metric, matched budgets, identical initial 8)  T4 cost from actual design overlap
T5 checkpoint/recovery (sandbox, stand-in observe = exact first-yield proxy; no MOOSE)  T6 hard cap  T7 guard  T8 V3 untouched."""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import hashlib, json, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import c3_common as C
R = {}; OUT = HERE / "preflight"; OUT.mkdir(exist_ok=True); T = C.T
man = dict(l.split("  ", 1)[::-1] for l in (T / "manifests/MANIFEST_truss.sha256").read_text().splitlines())
# T1
files = C.ORACLE_FILES + ["library/TLIB4096_v1.csv", "library/TREF_v1.csv", "controller/truss_v2_compat.py", "oracle/mesh_TL1/layout.json"]
R["T1_frozen"] = dict(v2_v1=C.W.check_frozen(), tl1={f: man.get(f) == C.sha(T / f) for f in files}, oracle_id=C.ORACLE_ID)
R["T1_frozen"]["pass_"] = all(R["T1_frozen"]["tl1"].values())
# T2
lib = C.library(); D = lib.directions; ref = pd.read_csv(C.TREF_CSV); P = ref[["z1", "z2", "z3"]].to_numpy()
mind = float(np.degrees(np.arccos(np.clip((P @ D.T).max(1), -1, 1))).min())
R["T2_references"] = dict(n=len(ref), accepted=int(ref.accepted.sum()), min_angle_ref_to_any_candidate_deg=mind,
                          ref_keys_in_candidate_keys=len({C.keyhash(p) for p in P} & {C.keyhash(d) for d in D}),
                          trial_store_contains_refs=False, note="references are read only by evaluate_c3.py; controllers never receive them")
R["T2_references"]["pass_"] = bool(len(ref) == 482 and ref.accepted.all() and mind > 0.1 and R["T2_references"]["ref_keys_in_candidate_keys"] == 0)
# T3
anti = np.r_[np.arange(4096, 8192), np.arange(4096)]; t3 = {}
for s in C.STARTS:
    ini = C.initial_design(lib, s); v2i = C.W.V2Controller(lib, None, C.W.V2Settings(symmetry="none")).initial_design(s)
    mo = C.maximin_order(lib, s); ro = C.random_order(lib, s)
    t3[s] = dict(init_equals_v2=ini == v2i, axmm_prefix=mo[:8] == ini, rand_prefix=ro[:8] == ini, axmm_unique=len(set(mo)) == len(mo), rand_unique=len(set(ro)) == len(ro),
                 axmm_second_is_antipode_of_first=bool(mo[1] == anti[mo[0]]), n_antipodal_pairs_in_axmm64=int(sum(anti[c] in set(mo[:64]) for c in mo[:64]) // 2))
R["T3_designs"] = dict(per_start=t3, distinct_initial_designs=len({frozenset(C.initial_design(lib, s)) for s in C.STARTS}), budget=C.BUDGET,
                       note="AXMM picks the exact antipode as its 2nd point: possible only with the SIGNED angle (axial distance of an antipode is 0)")
R["T3_designs"]["pass_"] = bool(all(all(v for k, v in x.items() if k != "n_antipodal_pairs_in_axmm64") for x in t3.values()) and R["T3_designs"]["distinct_initial_designs"] == 9)
# T4
uniq = set()
for s in C.STARTS:
    uniq |= set(C.initial_design(lib, s)) | set(C.maximin_order(lib, s)[:64]) | set(C.random_order(lib, s)[:64])
cpu_obs = float(ref.cpu_s.mean()); p95 = float(ref.cpu_s.quantile(0.95))
R["T4_cost"] = dict(unique_baseline_runs=len(uniq), v2_new_runs_upper=9 * 56, moose_cpu_s_mean=cpu_obs,
                    projected_cpu_h=(len(uniq) + 9 * 56) * cpu_obs * 1.05 / 3600 + 0.05, projected_cpu_h_p95_per_obs=(len(uniq) + 9 * 56) * p95 / 3600 + 0.05,
                    stage1_charge_cpu_h=0.10, cap_cpu_h=8.0)
R["T4_cost"]["pass_"] = bool(R["T4_cost"]["projected_cpu_h_p95_per_obs"] + 0.10 + 0.25 < 8.0)
print(json.dumps({k: v.get("pass_") for k, v in R.items()}), R["T4_cost"], flush=True)

# T5 / T6 sandbox
import truss_oracle as TO
S = np.asarray(C.CAL["Sbar"]); proxy = lambda d: float((TO.SY / np.abs(S @ d)).min())
calls = {"n": 0}
def fake_observe(d, wd, cal, **kw):
    calls["n"] += 1; Path(wd).mkdir(parents=True); r = proxy(np.asarray(d))
    return dict(direction=list(d), accepted=True, crossed=True, yield_radius=r, stress_mandel=list(r * np.asarray(d)), equilibrium_rel_err_max=0.0,
                achieved_dir_err_deg=0.0, periodic_check=dict(rel=0.0), failed_steps=0, cpu_s=0.0, flags=[])
def sandbox(name):
    sb = OUT / f"sandbox_{name}_{time.strftime('%H%M%S')}"; sb.mkdir()
    C.HERE = sb; C.TRIALS = sb / "trials"; C.INDEX = C.TRIALS / "index.jsonl"; C.LEDGER = sb / "cpu_ledger.jsonl"; return sb
real_observe = TO.observe; TO.observe = C.TO.observe = fake_observe
class Crash(RuntimeError):
    pass
class CrashingOracle(C.C3Oracle):
    def __init__(self, req, after):
        super().__init__(req); self.after = after
    def evaluate(self, d):
        if self.calls >= self.after:
            raise Crash()
        return super().evaluate(d)
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    sandbox("uninterrupted"); calls["n"] = 0
    a = C.W.V2Controller(lib, C.C3Oracle("T5a"), C.W.V2Settings(symmetry="none", budget=24)).run(0); na = calls["n"]
    sandbox("interrupted"); calls["n"] = 0
    try:
        C.W.V2Controller(lib, CrashingOracle("T5b", 14), C.W.V2Settings(symmetry="none", budget=24)).run(0)
    except Crash:
        pass
    n_before = calls["n"]
    b = C.W.V2Controller(lib, C.C3Oracle("T5b2"), C.W.V2Settings(symmetry="none", budget=24)).run(0)
    reqs = [json.loads(l) for l in (C.HERE / "requests.jsonl").read_text().splitlines()]
R["T5_recovery"] = dict(uninterrupted_calls=na, interrupted_after=n_before, total_new_runs_after_resume=calls["n"], identical_sequence=a["sequence"] == b["sequence"],
                        identical_scores=bool(all(np.array_equal(x, y) for x, y in zip(a["scores"], b["scores"]))), reused_on_resume=sum(r["reused"] for r in reqs))
R["T5_recovery"]["pass_"] = bool(R["T5_recovery"]["identical_sequence"] and R["T5_recovery"]["identical_scores"] and calls["n"] == na)
# T6 cap
sandbox("cap"); C.ledger_add("simulated prior use", 7.9 * 3600)
try:
    C.get(D[123], "T6"); R["T6_cap"] = dict(raised=False, pass_=False)
except C.CapReached as e:
    R["T6_cap"] = dict(raised=True, message=str(e), moose_runs=0, pass_=True)
TO.observe = C.TO.observe = real_observe
# T7 guard, T8 V3 untouched
R["T7_guard"] = dict(foreign_moose_now=C.foreign_moose(), pass_=not C.foreign_moose())
V3D = C.CL / "response_adaptive_v3_2026"
R["T8_v3_untouched"] = dict(protocol_files={f: C.sha(V3D / f) == h for h, f in [l.split() for l in open(V3D / "PROTOCOL.sha256")]})
R["T8_v3_untouched"]["pass_"] = all(R["T8_v3_untouched"]["protocol_files"].values())
R["ALL_PASS"] = all(v["pass_"] for k, v in R.items() if isinstance(v, dict) and "pass_" in v)
f = OUT / f"preflight_{time.strftime('%Y%m%dT%H%M%S')}.json"; f.write_text(json.dumps(R, indent=1, default=float))
print(json.dumps({k: (v.get("pass_") if isinstance(v, dict) else v) for k, v in R.items()}), json.dumps(R["T5_recovery"]), json.dumps(R["T4_cost"]))

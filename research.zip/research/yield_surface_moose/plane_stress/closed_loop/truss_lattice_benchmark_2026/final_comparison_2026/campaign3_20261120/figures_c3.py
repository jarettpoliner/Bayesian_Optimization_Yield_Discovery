#!/usr/bin/env python3
"""Manuscript figures (SVG + PDF + PNG) for the TL1 three-method comparison, generated from the completed MOOSE outputs and the frozen evaluation.
Measured MOOSE data (references, campaign observations, bar fields) are drawn as points/bars; GP quantities are always labelled as predictions.
No continuous surface is interpolated from sparse references.   python -B figures_c3.py"""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, warnings
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, LogNorm, Normalize
from matplotlib.figure import Figure
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import c3_common as C
T = C.T; EV = HERE / "evaluation"; FIG = HERE / "figures"; FIG.mkdir(exist_ok=True)
MC = {"V2": "#2a78d6", "AXMM": "#eb6834", "RANDOM": "#1baf7a"}; MN = {"V2": "V2-A20 BO+MES", "AXMM": "angular maximin", "RANDOM": "random"}
FAMC = dict(zip(["FH", "FI60", "FI120", "K0", "K60", "K120"], ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]))
SEQ = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#86b6ef", "#3987e5", "#256abf", "#184f95", "#0d366b"])
SEQO = LinearSegmentedColormap.from_list("seqo", ["#fde0d2", "#f6a785", "#eb6834", "#b84a1f", "#7a2e10"])
SEQG = LinearSegmentedColormap.from_list("seqg", ["#c9efe0", "#7fd3b2", "#1baf7a", "#137d57", "#0b4d36"])
MRAMP = {"V2": SEQ, "AXMM": SEQO, "RANDOM": SEQG}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d4"
plt.rcParams.update({"font.size": 8.5, "font.family": "DejaVu Sans", "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.5, "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": "white",
                     "axes.facecolor": "white", "savefig.dpi": 200, "lines.linewidth": 1.6, "svg.fonttype": "none", "pdf.fonttype": 42})


def plainlog(ax, axis="both", ticks=None):
    """log axis with plain decimal labels and no minor-tick labels."""
    from matplotlib.ticker import NullFormatter, ScalarFormatter, FuncFormatter
    f = FuncFormatter(lambda v, _: f"{v:g}")
    for a in (["x", "y"] if axis == "both" else [axis]):
        ax_ = ax.xaxis if a == "x" else ax.yaxis
        ax_.set_major_formatter(f); ax_.set_minor_formatter(NullFormatter())


def save(fig, name):
    for ext in ("svg", "pdf", "png"):
        fig.savefig(FIG / f"{name}.{ext}", bbox_inches="tight")
    plt.close(fig)


def eqarea(P):
    """Lambert equal-area coordinates of unit Mandel vectors; hemisphere sqrt2*sxy >= 0 at x-offset -1.6, < 0 at +1.6."""
    P = np.atleast_2d(P); up = P[:, 2] >= 0; Q = P * np.where(up, 1, -1)[:, None]; k = np.sqrt(2 / (1 + Q[:, 2]))
    return np.column_stack([np.where(up, -1.6, 1.6) + k * Q[:, 0], k * Q[:, 1]])


def disks(ax, label=True):
    for off, t in ((-1.6, "√2σxy ≥ 0"), (1.6, "√2σxy < 0")):
        ax.add_patch(plt.Circle((off, 0), np.sqrt(2), fill=False, color=INK2, lw=0.7))
        if label:
            ax.text(off, -1.62, t, ha="center", va="top", fontsize=7, color=INK2)
    ax.set_aspect("equal"); ax.set_xlim(-3.1, 3.1); ax.set_ylim(-1.85, 1.5); ax.axis("off")


lib = C.library(); D = lib.directions; ref = pd.read_csv(C.TREF_CSV); Pref = ref[["z1", "z2", "z3"]].to_numpy()
tab = pd.read_csv(T / "pilot/tl1_reference_table.csv").set_index("ref_id").loc[ref.ref_id].reset_index()
M = pd.read_csv(EV / "metrics.csv"); PR = pd.read_csv(EV / "predictions.csv"); PD = pd.read_csv(EV / "paired.csv"); CO = pd.read_csv(EV / "cost.csv")
REG = json.loads((EV / "regions.json").read_text()); DES = {(m, s): json.load(open(HERE / "runs" / m / f"s{s}" / "design.json")) for m in C.METHODS for s in C.STARTS}


# ---------------------------------------------------------------- physical figures (pilot code, all formats)
def physical():
    sys.path.insert(0, str(T / "pilot")); import figures as PF
    orig = Figure.savefig
    def multi(self, fname, *a, **k):
        p = Path(fname); k.pop("bbox_inches", None)
        for ext in ("svg", "pdf", "png"):
            orig(self, FIG / f"P_{p.stem}.{ext}", *a, bbox_inches="tight", **k)
    Figure.savefig = multi
    try:
        PF.fig_architecture(); PF.fig_fields(); cal = json.loads((T / "oracle/calibration_TL1.json").read_text()); PF.fig_surface(tab, cal)
    finally:
        Figure.savefig = orig


def ref3d():
    fig = plt.figure(figsize=(10, 4.6)); X = Pref * ref.yield_radius.to_numpy()[:, None]; dom = tab[[f"share_{f}" for f in FAMC]].to_numpy().argmax(1)
    for i, (el, az) in enumerate(((22, -60), (22, 30))):
        ax = fig.add_subplot(1, 2, i + 1, projection="3d")
        for j, f in enumerate(FAMC):
            m = dom == j
            if m.any():
                ax.scatter(X[m, 0], X[m, 1], X[m, 2], s=7, color=FAMC[f], depthshade=False, label=f"dominant yield: {f}")
        ax.view_init(el, az); ax.set_xlabel("σxx [MPa]"); ax.set_ylabel("σyy [MPa]"); ax.set_zlabel("√2 σxy [MPa]"); ax.set_box_aspect((1, 1, 1))
        lim = 16; ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim); ax.set_title(f"view elev {el}°, azim {az}°", fontsize=8)
    fig.axes[0].legend(loc="upper left", bbox_to_anchor=(0, 1.02), frameon=False, fontsize=7)
    fig.suptitle("Independent MOOSE yield-surface references (482 points r·d, Mandel stress; points only, no interpolation)", x=0.02, ha="left", fontsize=9.5)
    save(fig, "C03_reference_surface_mandel3d")


# ---------------------------------------------------------------- acquisition before / after (V2, start 0)
def acquisition():
    sc = np.load(HERE / "runs/V2/s0/scores_f32.npy"); st = pd.read_csv(HERE / "runs/V2/s0/steps.csv"); axes = DES[("V2", 0)]["axes"]
    i = 33 - 8 - 1                                                                    # score array row that chose test 33 (n_real = 32)
    fig, axs = plt.subplots(1, 2, figsize=(12, 3.9))
    for ax, k, title in ((axs[0], i, f"before test 33 (n = 32): acquisition = GP latent variance"), (axs[1], i + 1, "after the MOOSE result of test 33 (n = 33)")):
        v = sc[k].astype(float); ok = np.isfinite(v); E = eqarea(D[ok]); n_obs = 8 + k
        im = ax.scatter(E[:, 0], E[:, 1], c=v[ok], cmap=SEQ, norm=LogNorm(np.nanpercentile(sc[i:i + 2], 5), np.nanmax(sc[i:i + 2])), s=5, marker="h", linewidths=0, rasterized=True)
        O = eqarea(D[axes[:n_obs]]); ax.scatter(O[:, 0], O[:, 1], s=14, facecolor="white", edgecolor=INK, lw=0.7, label="MOOSE observations")
        ch = eqarea(D[[int(st.candidate.iloc[k])]]); ax.scatter(ch[:, 0], ch[:, 1], s=70, marker="*", color=MC["AXMM"], edgecolor=INK, lw=0.5,
                                                                   label="argmax = next experiment" if k == i else "argmax (test 34)")
        disks(ax); ax.set_title(title, fontsize=8.5); ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.28), ncol=2, frameon=False, fontsize=7)
    cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.01); cb.set_label("GP latent variance of log r\n= V2 acquisition score")
    fig.suptitle(f"V2-A20 acquisition on 8,192 signed candidates, start 0 (ML-II length scale {st.length_scale.iloc[i]:.2f} → {st.length_scale.iloc[i + 1]:.2f})", x=0.02, ha="left", fontsize=9.5)
    save(fig, "C04_v2_acquisition_before_after")


# ---------------------------------------------------------------- selections
def selections():
    fig, axs = plt.subplots(2, 3, figsize=(13, 5.6))
    for c, m in enumerate(C.METHODS):
        ax = axs[0, c]; ax_ = DES[(m, 0)]["axes"]; E = eqarea(D[ax_])
        ax.scatter(E[8:, 0], E[8:, 1], c=np.arange(9, 65), cmap=MRAMP[m], s=16, edgecolor="white", lw=0.3, vmin=1, vmax=64)
        ax.scatter(E[:8, 0], E[:8, 1], s=30, facecolor="none", edgecolor=INK, lw=1.0, label="shared initial 8")
        disks(ax); ax.set_title(f"{MN[m]}: start 0, tests 9–64 (shade = order)", fontsize=8.5)
        ax = axs[1, c]; A = np.vstack([D[DES[(m, s)]["axes"][8:]] for s in C.STARTS]); E = eqarea(A)
        ax.scatter(E[:, 0], E[:, 1], s=4, color=MC[m], alpha=0.45, lw=0); disks(ax); ax.set_title(f"{MN[m]}: all 9 starts, tests 9–64 (504 points)", fontsize=8.5)
    axs[0, 1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.02), frameon=False, fontsize=7)
    fig.suptitle("Actual sequential MOOSE loading-direction selections (signed directions; Lambert equal-area maps of both √2σxy hemispheres)", x=0.02, ha="left", fontsize=9.5)
    save(fig, "C05_selections")


# ---------------------------------------------------------------- reconstructions on the sweeps
def reconstructions():
    import warnings as w
    B = C.W.B
    for sw, (e1, e2), lab in (("sweep_biax", ((1, 0, 0), (0, 1, 0)), "σxx–σyy plane (σxy = 0)"),
                              ("sweep_eb_ps", ((1 / np.sqrt(2), 1 / np.sqrt(2), 0), (0, 0, 1)), "equal-biaxial → shear great circle")):
        e1, e2 = np.array(e1), np.array(e2); nrm = np.cross(e1, e2); t = np.radians(np.arange(0, 360.01, 1.0)); G = np.cos(t)[:, None] * e1 + np.sin(t)[:, None] * e2
        R = ref[ref.set == sw]; fig, axs = plt.subplots(3, 4, figsize=(14, 7.6), sharex=True, sharey=True)
        for r_, m in enumerate(C.METHODS):
            X = np.array(DES[(m, 0)]["directions"]); rr = np.array(DES[(m, 0)]["radii"])
            for c_, n in enumerate(C.CHECKPOINTS):
                ax = axs[r_, c_]
                with w.catch_warnings():
                    w.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(X[:n], rr[:n])
                mu, vl = g.predict_log(G); sd = np.sqrt(vl + g.theta()[2])
                ax.fill_between(np.degrees(t), np.exp(mu - 1.96 * sd), np.exp(mu + 1.96 * sd), color=MC[m], alpha=0.15, lw=0, label="GP 95 % band (prediction)")
                ax.plot(np.degrees(t), np.exp(mu), color=MC[m], lw=1.3, label="GP mean (prediction)")
                ax.scatter(R.sweep_t_deg, R.yield_radius, s=6, color=INK, zorder=3, label="MOOSE references (held out)")
                near = np.abs(np.degrees(np.arcsin(np.clip(X[:n] @ nrm, -1, 1)))) <= 4.0
                if near.any():
                    q = X[:n][near]; tq = np.degrees(np.arctan2(q @ e2, q @ e1)) % 360
                    ax.scatter(tq, rr[:n][near], s=26, marker="D", color=MC[m], edgecolor="white", lw=0.6, zorder=4, label="campaign MOOSE obs. within 4° of plane")
                if r_ == 0:
                    ax.set_title(f"n = {n}", fontsize=9)
                if c_ == 0:
                    ax.set_ylabel(f"{MN[m]}\nr [MPa]")
                ax.set_xticks(range(0, 361, 90))
        for ax in axs[-1]:
            ax.set_xlabel("angle along the circle [deg]")
        h, l = axs[0, 3].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, -0.02))
        fig.suptitle(f"GP reconstructions (start 0) on the {lab}, vs held-out MOOSE references", x=0.02, ha="left", fontsize=9.5)
        save(fig, f"C06_reconstruction_{sw}")


# ---------------------------------------------------------------- error trajectories, cost, paired
def errors():
    A = M[M.surrogate == "A20"]; fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
    for ax, met, lab in ((axs[0], "area_mean", "area-weighted mean |r̂/r − 1| (PRIMARY)"), (axs[1], "area_max", "max |r̂/r − 1| (area set)"), (axs[2], "cusp_mean", "mean |r̂/r − 1|, cusp region")):
        for m in C.METHODS:
            g = A[A.method == m]
            for s in C.STARTS:
                q = g[g.start == s].sort_values("n"); ax.plot(q.n, q[met] * 100, color=MC[m], lw=0.6, alpha=0.35)
            md = g.groupby("n")[met].median() * 100; ax.plot(md.index, md.values, "-o", color=MC[m], lw=2, ms=4, label=f"{MN[m]} (median of 9)")
        ax.set_xscale("log"); ax.set_yscale("log"); plainlog(ax); ax.set_xticks(C.CHECKPOINTS); ax.set_xlabel("number of MOOSE experiments n")
        ax.set_ylabel(lab.split(" (")[0] + " [%]"); ax.set_title(lab, fontsize=8.5, loc="left"); ax.axvline(33, color=INK2, lw=0.8, ls="--")
    axs[0].legend(frameon=False, fontsize=7); save(fig, "C07_error_vs_n")
    fig, ax = plt.subplots(figsize=(5.6, 3.8)); J = A.merge(CO, on=["method", "start", "n"])
    for m in C.METHODS:
        g = J[J.method == m]; ax.scatter(g.total_cpu_h, g.area_mean * 100, s=12, color=MC[m], alpha=0.6, lw=0)
        md = g.groupby("n")[["total_cpu_h", "area_mean"]].median(); ax.plot(md.total_cpu_h, md.area_mean * 100, "-o", color=MC[m], ms=4, label=MN[m])
    ax.set_xscale("log"); ax.set_yscale("log"); plainlog(ax); ax.set_xlabel("cumulative CPU-hours (MOOSE + controller) per campaign"); ax.set_ylabel("area-weighted mean error [%]")
    ax.legend(frameon=False, fontsize=7); ax.set_title("Error vs computational cost (points = starts × n ∈ {8,16,33,64})", fontsize=8.5, loc="left"); save(fig, "C08_error_vs_cpu")
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.4), gridspec_kw=dict(width_ratios=[1.45, 1]))
    P = PD[(PD.surrogate == "A20") & (PD.metric == "area_mean")]; pairs = [("V2", "AXMM"), ("V2", "RANDOM"), ("AXMM", "RANDOM")]; cols = [MC["AXMM"], MC["RANDOM"], INK2]
    for j, ((a, b), col) in enumerate(zip(pairs, cols)):
        q = P[(P.a == a) & (P.b == b)].sort_values("n"); y = np.arange(len(q)) * 4 + j
        axs[0].errorbar(q.ratio_HL, y, xerr=[q.ratio_HL - q.ratio_ci_lo, q.ratio_ci_hi - q.ratio_HL], fmt="o", color=col, ms=5, capsize=2, label=f"err({MN[b]}) / err({MN[a]})")
        for yy, (_, x) in zip(y, q.iterrows()):
            if x.n > 8:
                axs[0].text(x.ratio_ci_hi * 1.02, yy, f"p(Holm,3)={x.p_holm3:.3f}; {x.wins_a}/9", va="center", fontsize=6.5, color=INK2)
    axs[0].axvline(1, color=INK, lw=0.8); axs[0].set_xscale("log"); plainlog(axs[0], "x"); axs[0].set_xlim(0.8, 2.6); axs[0].set_xticks([0.8, 0.9, 1, 1.1, 1.25, 1.5, 2, 2.5])
    axs[0].set_yticks(np.arange(4) * 4 + 1); axs[0].set_yticklabels([f"n = {n}" for n in C.CHECKPOINTS])
    axs[0].set_xlabel("paired error ratio err(b)/err(a): Hodges–Lehmann with exact 96 % CI (> 1: a better)\nn = 8 identical by design (shared initial 8)")
    axs[0].legend(frameon=False, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=3)
    axs[0].set_title("Paired comparisons over 9 matched starts (primary metric)", fontsize=8.5, loc="left")
    for j, (a, b) in enumerate(pairs):
        for k, n in enumerate((33, 64)):
            ea = M[(M.surrogate == "A20") & (M.n == n) & (M.method == a)].set_index("start").area_mean; eb = M[(M.surrogate == "A20") & (M.n == n) & (M.method == b)].set_index("start").area_mean
            r = (eb / ea).loc[list(C.STARTS)]; xx = j * 3 + k + np.linspace(-0.25, 0.25, 9)
            axs[1].scatter(xx, r, s=14, color=cols[j], alpha=0.8, lw=0)
    axs[1].axhline(1, color=INK, lw=0.8); axs[1].set_yscale("log"); plainlog(axs[1], "y"); axs[1].set_yticks([0.7, 0.8, 0.9, 1, 1.25, 1.5, 2]); axs[1].set_xticks([0, 1, 3, 4, 6, 7])
    axs[1].set_xticklabels(["V2/AXMM\nn=33", "n=64", "V2/RAND\nn=33", "n=64", "AXMM/RAND\nn=33", "n=64"], fontsize=7); axs[1].set_ylabel("per-start ratio err(b)/err(a)")
    axs[1].set_title("Per-start paired ratios", fontsize=8.5, loc="left"); save(fig, "C09_paired_ratios")


def local_maps():
    fig, axs = plt.subplots(1, 3, figsize=(14, 3.6)); E = eqarea(Pref); cusp = ref.ref_id.isin(REG["cusp_ids"]).to_numpy(); tr = ref.ref_id.isin(REG["transition_ids"]).to_numpy()
    q = PR[(PR.surrogate == "A20") & (PR.n == 33)]; vmax = 0.25
    for ax, m in zip(axs, C.METHODS):
        e = q[q.method == m].groupby("ref_id").err.apply(lambda x: np.mean(np.abs(x))).loc[ref.ref_id].to_numpy()
        im = ax.scatter(E[:, 0], E[:, 1], c=e, cmap=SEQ, norm=Normalize(0, vmax), s=10, lw=0)
        ax.scatter(E[cusp, 0], E[cusp, 1], s=26, facecolor="none", edgecolor=MC["AXMM"], lw=0.7, label="cusp region refs")
        ax.scatter(E[tr & ~cusp, 0], E[tr & ~cusp, 1], s=22, marker="s", facecolor="none", edgecolor=INK2, lw=0.5, label="mechanism-transition refs")
        disks(ax); ax.set_title(f"{MN[m]}, n = 33: mean over 9 starts of |r̂/r − 1| at each reference", fontsize=8)
    axs[0].legend(loc="upper left", frameon=False, fontsize=6.5, bbox_to_anchor=(-0.05, 1.12), ncol=2)
    fig.colorbar(im, ax=axs, fraction=0.02, pad=0.01).set_label("|relative error| (clipped at 25 %)"); save(fig, "C10a_local_error_maps")
    fig, ax = plt.subplots(figsize=(8, 3.4)); mets = [("area_mean", "global (area)"), ("nonfeature_mean", "non-feature"), ("cusp_mean", "cusp"), ("trans_mean", "transition"), ("sweep_mean", "sweeps")]
    w = 0.26
    for j, m in enumerate(C.METHODS):
        for k, n in enumerate((33, 64)):
            g = M[(M.surrogate == "A20") & (M.method == m) & (M.n == n)]; med = [g[c].median() * 100 for c, _ in mets]
            x = np.arange(len(mets)) * 2.2 + k * 1.0 + (j - 1) * w
            ax.bar(x, med, width=w * 0.92, color=MC[m], alpha=1.0 if n == 33 else 0.55, label=f"{MN[m]}, n={n}")
    ax.set_xticks(np.arange(len(mets)) * 2.2 + 0.5); ax.set_xticklabels([l for _, l in mets]); ax.set_ylabel("median over starts of mean |error| [%]"); ax.set_yscale("log"); plainlog(ax, "y")
    ax.legend(frameon=False, fontsize=6.5, ncol=3); ax.set_title("Regional reconstruction error (solid n = 33, light n = 64)", fontsize=8.5, loc="left"); save(fig, "C10b_regional_errors")


def calibration():
    fig, axs = plt.subplots(2, 3, figsize=(12, 7))
    for r_, n in enumerate((33, 64)):
        for c_, m in enumerate(C.METHODS):
            ax = axs[r_, c_]; q = PR[(PR.surrogate == "A20") & (PR.n == n) & (PR.method == m) & PR.ref_id.isin(ref.ref_id[ref.set == "area"])]
            ae = np.abs(np.log(q.pred_r / q.meas_r)); ax.scatter(q.sd_log, ae, s=3, color=MC[m], alpha=0.35, lw=0)
            lim = max(q.sd_log.max(), ae.max()) * 1.05; xx = np.linspace(0, lim, 10); ax.plot(xx, 1.96 * xx, color=INK, lw=0.9, ls="--", label="|error| = 1.96 × predictive sd")
            g = M[(M.surrogate == "A20") & (M.n == n) & (M.method == m)]
            ax.set_title(f"{MN[m]}, n = {n}: coverage95 median {g.cov95.median():.2f}, Spearman ρ median {g.spearman_sd_vs_abs_log_err.median():.2f}", fontsize=7.5)
            ax.set_xlabel("GP predictive sd of log r (model uncertainty)"); ax.set_ylabel("held-out |log error| vs MOOSE reference")
    axs[0, 0].legend(frameon=False, fontsize=7); fig.suptitle("Predicted uncertainty (x) vs actual held-out error (y), 338 area references × 9 starts", x=0.02, ha="left", fontsize=9.5)
    save(fig, "C11_uncertainty_vs_error")
    fig, axs = plt.subplots(2, 3, figsize=(11, 7), sharex=True, sharey=True)
    for r_, n in enumerate((33, 64)):
        for c_, m in enumerate(C.METHODS):
            ax = axs[r_, c_]; q = PR[(PR.surrogate == "A20") & (PR.n == n) & (PR.method == m)]
            ax.scatter(q.meas_r, q.pred_r, s=3, color=MC[m], alpha=0.35, lw=0); ax.plot([5, 17], [5, 17], color=INK, lw=0.8)
            ax.set_title(f"{MN[m]}, n = {n}", fontsize=8); ax.set_xlabel("measured MOOSE r [MPa]"); ax.set_ylabel("GP-predicted r [MPa]")
    fig.suptitle("Predicted vs measured yield radii at all 482 references (9 starts pooled)", x=0.02, ha="left", fontsize=9.5); save(fig, "C12_predicted_vs_measured")


def hyper():
    fig, axs = plt.subplots(1, 2, figsize=(10, 3.4))
    for s in C.STARTS:
        st = pd.read_csv(HERE / f"runs/V2/s{s}/steps.csv"); st = st[st.n_real.notna()]
        axs[0].plot(st.n_real, st.length_scale, color=MC["V2"], lw=0.8, alpha=0.7); axs[1].plot(st.n_real, st.latent_var, color=MC["V2"], lw=0.8, alpha=0.7)
    axs[0].set_xlabel("real observations n"); axs[0].set_ylabel("GP length scale"); axs[0].axvline(20, color=INK2, ls="--", lw=0.8); axs[0].text(20.5, axs[0].get_ylim()[1] * 0.95, "ML-II from n = 20", fontsize=7, color=INK2, va="top")
    axs[1].set_xlabel("real observations n"); axs[1].set_ylabel("max latent variance (chosen score)"); axs[1].set_yscale("log"); plainlog(axs[1], "y")
    fig.suptitle("V2-A20 hyper-parameter and acquisition trajectories (9 starts)", x=0.02, ha="left", fontsize=9.5); save(fig, "C13_v2_hyperparameters")


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    physical(); ref3d(); acquisition(); selections(); reconstructions(); errors(); local_maps(); calibration(); hyper()
    print(sorted({p.stem for p in FIG.iterdir()}))

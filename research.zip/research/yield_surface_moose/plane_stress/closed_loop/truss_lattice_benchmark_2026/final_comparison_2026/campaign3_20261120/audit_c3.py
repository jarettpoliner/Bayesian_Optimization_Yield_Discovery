#!/usr/bin/env python3
"""Independent integrity audit of campaign3 (read-only except audit/ and MANIFEST.sha256).   python -B audit_c3.py"""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import hashlib, json, subprocess, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import c3_common as C
A = {}; T = C.T; PS = C.CL.parent; (HERE / "audit").mkdir(exist_ok=True)
# frozen files: all must match PROTOCOL.sha256, except evaluate_c3.py, which is covered by documented Amendment 1 (original kept, hash-equal)
fz = [l.split() for l in (HERE / "PROTOCOL.sha256").read_text().splitlines()]; amd = [l.split() for l in (HERE / "amendments/AMENDMENT_1.sha256").read_text().splitlines()]
orig_h = dict(fz)["evaluate_c3.py"] if False else {f: h for h, f in fz}["evaluate_c3.py"]
A["protocol_freeze"] = dict(unchanged={f: C.sha(HERE / f) == h for h, f in fz if f != "evaluate_c3.py"},
                            evaluator_original_kept=C.sha(HERE / "amendments/evaluate_c3_FROZEN_original.py") == orig_h,
                            evaluator_matches_amendment_record={f: h for h, f in amd}["evaluate_c3.py"] == C.sha(HERE / "evaluate_c3.py"))
A["protocol_freeze"]["ok"] = bool(all(A["protocol_freeze"]["unchanged"].values()) and A["protocol_freeze"]["evaluator_original_kept"] and A["protocol_freeze"]["evaluator_matches_amendment_record"])
recs = {}
for l in (HERE / "trials/index.jsonl").read_text().splitlines():
    x = json.loads(l); recs[x["keyhash"]] = json.loads((HERE / x["record"]).read_text())
frozen_t = time.mktime(time.strptime((HERE / "FROZEN_AT.txt").read_text().strip()[:19], "%Y-%m-%dT%H:%M:%S"))
first_trial = min((HERE / "trials/records" / f"{k}.json").stat().st_mtime for k in recs)
A["frozen_before_first_trial"] = dict(frozen=time.ctime(frozen_t), first_trial=time.ctime(first_trial), ok=bool(frozen_t < first_trial))
man = dict(l.split("  ", 1)[::-1] for l in (T / "manifests/MANIFEST_truss.sha256").read_text().splitlines())
V3D = C.CL / "response_adaptive_v3_2026"
A["frozen_sources"] = dict(v2_v1=bool(C.W.check_frozen()), tl1=all(man.get(f) == C.sha(T / f) for f in C.ORACLE_FILES + ["library/TLIB4096_v1.csv", "library/TREF_v1.csv", "controller/truss_v2_compat.py"]),
                           v3_untouched=all(C.sha(V3D / f) == h for h, f in [l.split() for l in open(V3D / "PROTOCOL.sha256")]))
# completeness / matching
lib = C.library(); D = lib.directions; comp = {}
for m in C.METHODS:
    for s in C.STARTS:
        d = json.load(open(HERE / "runs" / m / f"s{s}" / "design.json")); ri = json.load(open(HERE / "runs" / m / f"s{s}" / "run_info.json"))
        ok_rec = all(recs[k]["valid"] and recs[k]["oracle_id"] == C.ORACLE_ID and recs[k]["yield_radius"] == r for k, r in zip(d["keyhashes"], d["radii"]))
        keys_match = all(C.keyhash(D[a] / np.linalg.norm(D[a])) == k for a, k in zip(d["axes"], d["keyhashes"]))   # same normalisation as c3_common.get
        comp[f"{m}_s{s}"] = dict(n=len(d["axes"]), unique=len(set(d["axes"])) == 64, init_ok=d["axes"][:8] == C.initial_design(lib, s), records_valid_and_equal=ok_rec,
                                 keys_match=keys_match, failed=len(d.get("failed", [])), oracle_id_ok=ri["oracle_id"] == C.ORACLE_ID)
A["campaigns"] = dict(n=len(comp), all_ok=all(x["n"] == 64 and x["unique"] and x["init_ok"] and x["records_valid_and_equal"] and x["keys_match"] and x["oracle_id_ok"] for x in comp.values()),
                      total_failed=sum(x["failed"] for x in comp.values()), detail=comp)
A["trials"] = dict(unique=len(recs), accepted=sum(r["accepted"] for r in recs.values()), valid=sum(r["valid"] for r in recs.values()),
                   max_equilibrium=max(r["equilibrium_rel_err_max"] for r in recs.values() if r["accepted"]), max_periodic=max(r["periodic_check"]["rel"] for r in recs.values() if r["accepted"]),
                   max_dir_err_deg=max(r["achieved_dir_err_deg"] for r in recs.values() if r["accepted"]), failed_steps=sum(r.get("failed_steps", 0) for r in recs.values()))
# baselines recomputed
A["baseline_rules"] = dict(axmm=all([c for c in C.maximin_order(lib, s) if c not in set(json.load(open(HERE / f"runs/AXMM/s{s}/design.json"))["failed"])][:64] ==
                                    json.load(open(HERE / f"runs/AXMM/s{s}/design.json"))["axes"] for s in C.STARTS),
                           random=all([c for c in C.random_order(lib, s) if c not in set(json.load(open(HERE / f"runs/RANDOM/s{s}/design.json"))["failed"])][:64] ==
                                      json.load(open(HERE / f"runs/RANDOM/s{s}/design.json"))["axes"] for s in C.STARTS))
# leakage
ref = pd.read_csv(C.TREF_CSV); P = ref[["z1", "z2", "z3"]].to_numpy(); used = np.unique(np.concatenate([json.load(open(HERE / f"runs/{m}/s{s}/design.json"))["axes"] for m in C.METHODS for s in C.STARTS]))
A["leakage"] = dict(min_angle_campaign_obs_to_reference_deg=float(np.degrees(np.arccos(np.clip((D[used] @ P.T).max(), -1, 1)))),
                    reference_keys_in_store=len({C.keyhash(p) for p in P} & set(recs)),
                    files_reading_TREF=[f for f in ("c3_common.py", "run_c3.py", "evaluate_c3.py", "preflight_c3.py", "figures_c3.py") if "TREF_CSV" in (HERE / f).read_text()],
                    controller_code_reads_TREF="TREF" in (HERE / "run_c3.py").read_text())
# V2: pseudo-observations, replay from the store with MOOSE disabled
pseudo = []
for s in C.STARTS:
    st = pd.read_csv(HERE / f"runs/V2/s{s}/steps.csv"); st = st[st.n_real.notna()]; pseudo.append(bool((st.n_training_points == st.n_real).all()))
def no_moose(*a, **k):
    raise RuntimeError("audit replay attempted a MOOSE run")
C.TO.observe = no_moose; rep = {}
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    for s in (0, 4):
        r = C.W.V2Controller(lib, C.C3Oracle(f"AUDIT_replay_s{s}"), C.W.V2Settings(symmetry="none", schedule="A20", budget=64)).run(s)
        sc = np.load(HERE / f"runs/V2/s{s}/scores_f32.npy"); mine = np.array([np.where(np.isfinite(x), x, np.nan) for x in r["scores"]], np.float32)
        rep[s] = bool(r["sequence"] == json.load(open(HERE / f"runs/V2/s{s}/design.json"))["axes"] and np.array_equal(mine, sc, equal_nan=True))
A["v2"] = dict(no_pseudo_observations=all(pseudo), replay_bitwise_from_store=rep)
# evaluation recomputation (independent re-implementation of the primary metric for 3 cells)
M = pd.read_csv(HERE / "evaluation/metrics.csv"); B = C.W.B; chk = []
for m, s in (("V2", 0), ("AXMM", 3), ("RANDOM", 8)):
    d = json.load(open(HERE / f"runs/{m}/s{s}/design.json")); X = np.array(d["directions"]); r = np.array(d["radii"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(X[:33], r[:33])
    Aset = (ref.set == "area").to_numpy(); e = np.abs(g.predict_radius(P[Aset]) / ref.yield_radius.to_numpy()[Aset] - 1).mean()
    v = M[(M.method == m) & (M.start == s) & (M.n == 33) & (M.surrogate == "A20")].area_mean.iloc[0]; chk.append(dict(cell=f"{m}_s{s}_n33", recomputed=float(e), stored=float(v), rel=float(abs(e / v - 1))))
A["evaluation_recompute"] = dict(cells=chk, ok=all(x["rel"] < 1e-12 for x in chk))
led = [json.loads(l) for l in (HERE / "cpu_ledger.jsonl").read_text().splitlines()]
A["ledger"] = dict(total_cpu_h=sum(x["cpu_s"] for x in led) / 3600, moose_cpu_h=sum(x["cpu_s"] for x in led if x["item"].startswith("moose:")) / 3600,
                   sum_record_cpu_h=sum(r.get("cpu_s", 0) for r in recs.values()) / 3600, cap_cpu_h=8.0)
A["ledger"]["within_cap"] = A["ledger"]["total_cpu_h"] <= 8.0
f = subprocess.run(["find", str(PS), "-newer", str(HERE / "FROZEN_AT.txt"), "-type", "f", "-not", "-path", f"{T}/*"], capture_output=True, text=True).stdout.split()
grp = {}
for p in f:
    k = "/".join(Path(p).relative_to(PS).parts[:2]); grp[k] = grp.get(k, 0) + 1
A["outside_changes_since_freeze"] = grp
A["incomplete_runs_moved"] = sorted(str(p.relative_to(HERE)) for p in (HERE / "runs_incomplete").rglob("run_info.json")) if (HERE / "runs_incomplete").exists() else []
A["PASS"] = bool(A["protocol_freeze"]["ok"] and A["frozen_before_first_trial"]["ok"] and all(A["frozen_sources"].values()) and A["campaigns"]["all_ok"]
                 and A["baseline_rules"]["axmm"] and A["baseline_rules"]["random"] and A["leakage"]["reference_keys_in_store"] == 0 and not A["leakage"]["controller_code_reads_TREF"]
                 and A["v2"]["no_pseudo_observations"] and all(A["v2"]["replay_bitwise_from_store"].values()) and A["evaluation_recompute"]["ok"] and A["ledger"]["within_cap"])
(HERE / "audit/audit_c3.json").write_text(json.dumps(A, indent=1, default=float))
rows = [f"{C.sha(p)}  {p.relative_to(HERE)}" for p in sorted(HERE.rglob("*")) if p.is_file() and ".jitcache" not in p.parts and p.name != "MANIFEST.sha256" and not p.name.startswith(".")]
(HERE / "MANIFEST.sha256").write_text("\n".join(rows) + "\n")
print(json.dumps({k: v for k, v in A.items() if k not in ("campaigns",)} | dict(campaigns={k: v for k, v in A["campaigns"].items() if k != "detail"}), indent=1, default=float))

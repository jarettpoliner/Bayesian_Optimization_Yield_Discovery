# TL1 three-method physical comparison: preregistered protocol (campaign3_20261120)

**Freeze.** Written and hashed in `PROTOCOL.sha256` **before any campaign MOOSE run**. The hash covers this file and `c3_common.py`, `run_c3.py`, `evaluate_c3.py` and `preflight_c3.py`. Any later change is a documented amendment; the originals are kept.

**Authorization.** Option 2 of `../STAGE1_PREFLIGHT_REPORT.md`, under an 8 CPU-h hard cap covering everything. **V3 is excluded and untouched.**

## 1. Fixed inputs (hash-verified by `preflight_c3.py`, T1)

| Input | Specification |
|---|---|
| RVE | TL1 (`lattice/TL1_frozen.json`) |
| Oracle | `oracle/truss_oracle.py` as validated in V2. Calibration `calibration_TL1.json`; solver `DEFAULTS`; yield criterion: Levin macroscopic plastic strain ‖E_p‖ = 1e-4. Oracle identity `ORACLE_ID` = hash of the oracle code, calibration, mesh, constraint matrix, lattice and DEFAULTS |
| Candidates | TLIB-4096 v1: **8,192 signed directions**. d and −d are distinct experiments |
| Symmetry | None anywhere: no antipodal equivalence, no pseudo-observations, no shear mirror |
| References | TREF v1: 482 accepted MOOSE observations (`pilot/refs_TREF_v1_20261120T171229`). **Evaluator only** (`evaluate_c3.py`). The nearest reference is 0.33° from any candidate, so no campaign key can coincide with a reference. References are never in the trial store |

## 2. Methods (identical oracle, library, initial 8 and budget)

| Method | Rule |
|---|---|
| **V2** | Frozen `bomes_v2.V2Controller` through TV2C 1.0 with `V2Settings(symmetry='none', schedule='A20', budget=64)`. Matérn-3/2 GP on log r; acquisition = maximum latent predictive variance (MES); ML-II with 2 restarts from 20 real observations at every step, fixed hyper-parameters below; deterministic ties. Unchanged code |
| **AXMM** | Frozen V1 `angular_maximin` with the deterministic rule and the **signed atan2 great-circle angle**, from first(s), in greedy order with 16 spares; the first 64 valid observations are used. Verified signed: its 2nd point is the exact antipode of the 1st, which is impossible with an axial distance |
| **RANDOM** | Initial 8, then `numpy.random.default_rng(9000 + s).permutation` of the remaining signed candidates; the first 56 valid observations are used. Unique signed directions only |

## 3. Matched starts

- Starts s = 0, …, 8, giving 9 distinct initial designs (verified).
- first(s) = candidate 0 for s = 0, else `default_rng(7000 + s).choice(8192)`, the frozen V1/V2 rule.
- The **initial 8** = `V2Controller.initial_design(s)` = signed angular maximin from first(s). It is identical for all three methods (asserted) and measured once.
- **Budget:** 64 valid physical observations per method and start. **n = 33 is a checkpoint** of the same campaign.

## 4. Observation reuse

- Exact (ORACLE_ID, signed direction rounded to 12 decimals) matches only, within this campaign's trial store.
- So identical directions requested by different methods share one MOOSE run, and each method still counts it as its own observation.
- No reuse from references, validation or any other study.

## 5. Failures, validity and stopping

1. **Failed trial** (MOOSE error, threshold not reached, or any oracle flag): not counted.
   - V2 marks the direction unavailable (frozen rule).
   - AXMM and RANDOM take their next direction in order.
2. **Numerical validity of an accepted trial:** equilibrium ≤ 1e-6, direction error ≤ 1e-3°, periodicity ≤ 1e-8, no failed steps, r finite and positive. **Any accepted-but-invalid trial stops the campaign** (`NumericalInvalid`).
3. **A failed trial in an initial design stops the study**, so the matched initialization is never silently altered.
4. **The study stops if more than 2% of unique trials fail.**
5. **Hard cap:** a MOOSE launch is refused when ledger + 120 s in-flight allowance + 0.25 CPU-h evaluation reserve would exceed 8 CPU-h. The Stage 1 preflight is charged 0.10 CPU-h, an upper estimate.
6. **Guard:** any `*-opt` process outside this campaign's trial directory stops new launches.
7. **Execution order:** initial designs → AXMM and RANDOM → V2.
8. **Checkpoints:** `runs/<M>/s<k>/run_info.json`. Incomplete runs are moved to `runs_incomplete/`; the re-run is deterministic with exact reuse (verified in T5).

## 6. Evaluation (`evaluate_c3.py`; identical for all methods)

**Reconstruction GP.** The frozen GPv2 (Matérn-3/2, symmetry none), fitted to each campaign's first n observations at n ∈ {8, 16, 33, 64}:

| Role | Surrogate |
|---|---|
| Primary | A20 schedule |
| Sensitivity | FIXED (ℓ = 0.5) |

Error e = r̂/r_ref − 1 at each TREF reference.

**PRIMARY endpoint.** n = 33, A20, `area_mean` = mean |e| over the **338 area-uniform references**. Because the set is area-uniform, this is the area-weighted relative radial error.

**Secondary endpoints** (descriptive, with nominal and Holm-adjusted p-values):
- RMS, P95 and max error on the area set;
- the two 72-point sweeps (mean and max);
- **cusp region:** references within 15° of ±equal-biaxial;
- **transition region:** a reference with another reference within 10° whose dominant plastic family differs;
- **non-feature region:** area references outside both regions;
- calibration: 90% and 95% coverage, RMS z, and Spearman ρ between predictive sd and |log error|;
- predicted vs measured radii;
- all metrics at n = 8, 16 and 64;
- cost: cumulative MOOSE CPU of each method's own observations, plus controller CPU (V2's spread evenly over its 56 adaptive steps);
- **response dependence:** V2 re-run with a constant response (no MOOSE). Report its first divergence from the actual V2 design and the overlap of the selected sets, and the same comparison with AXMM.

The regions are defined from the reference MOOSE data alone, before any campaign. Chamfer distance is not computed: on a radial star-shaped surface sampled at fixed references, the radial error is the direct measure.

**Statistics.** For pair (a, b) at a given metric and n:
- L_s = log(err_b,s / err_a,s) over the 9 matched starts;
- exact two-sided Wilcoxon signed-rank test;
- Hodges-Lehmann ratio exp(HL) with its exact CI (n = 9: 6th and 40th Walsh averages, 96.1%);
- wins of a.

Comparisons: V2 vs AXMM, V2 vs RANDOM and AXMM vs RANDOM. Holm correction over the 3 comparisons within each (metric, n, surrogate) family.

**Primary decision** (n = 33, area_mean, A20; family {V2 vs AXMM, V2 vs RANDOM}, Holm over 2). "V2 ADVANTAGE over X" requires all of:
1. Holm-adjusted p < 0.05;
2. HL ratio CI lower bound > 1;
3. V2 better in ≥ 8 of 9 starts;
4. median paired error reduction > **0.13 percentage points**, the oracle numerical floor from the V2 validation (max |r_MOOSE/r_independent − 1| = 1.3e-3);
5. the same direction under FIXED: ≥ 7 of 9 wins and HL ratio > 1.

"V2 DISADVANTAGE" uses the mirror criteria. Anything else is "NO SUPPORTED DIFFERENCE".

**Practically meaningful:** V2 ADVANTAGE and HL ratio ≥ 1.10.

**Scope.** One deterministic RVE and 9 matched starts. A significant result is a reproducible paired effect on TL1, not a generalization across materials. A non-significant result is reported as such.

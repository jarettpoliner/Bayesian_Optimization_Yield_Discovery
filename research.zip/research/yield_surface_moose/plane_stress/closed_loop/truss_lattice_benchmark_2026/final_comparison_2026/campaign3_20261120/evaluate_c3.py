#!/usr/bin/env python3
"""EVALUATOR (frozen with PROTOCOL.md).  The only code that reads the TREF references.  python -B evaluate_c3.py
Reconstruction GP: frozen GPv2 (Matern-3/2, symmetry NONE, no pseudo-observations), schedule A20 (primary) and FIXED (sensitivity), fitted to
the first n observations of each campaign, n in CHECKPOINTS.  Error e = r_hat / r_ref - 1 at every TREF reference (r_hat = exp(GP mean of log r)).
Outputs: evaluation/metrics.csv, predictions_n33_n64.csv, paired.csv, claims.json, cost.csv, response_dependence.json"""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import itertools, json, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
from scipy import stats
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import c3_common as C
B = C.W.B; OUT = HERE / "evaluation"; SUR = {"A20": B.SCHEDULES["A20"], "FIXED": B.SCHEDULES["FIXED"]}
DELTA_NUM_PP = 0.13          # oracle numerical floor in percentage points (V2 validation max |r_moose/r_indep - 1| = 1.3e-3)


def ang(P, Q):
    cr = np.linalg.norm(np.cross(P[:, None, :], Q[None, :, :]), axis=2); return np.degrees(np.arctan2(cr, P @ Q.T))


def regions(ref):
    """evaluator-side regions from MOOSE reference data only (fixed before any campaign):
    CUSP = refs within 15 deg of +/-(1,1,0)/sqrt2 (equal biaxial; cusps found in the feasibility study);
    TRANSITION = refs with another ref within 10 deg whose dominant plastic family differs (dominant = largest plastic share at yield)."""
    P = ref[["z1", "z2", "z3"]].to_numpy(); eb = np.array([[1, 1, 0], [-1, -1, 0]]) / np.sqrt(2)
    cusp = ang(P, eb).min(1) <= 15.0
    fam = ref[[f"share_{f}" for f in ("FH", "FI60", "FI120", "K0", "K60", "K120")]].to_numpy().argmax(1); A = ang(P, P); np.fill_diagonal(A, 999)
    trans = np.array([np.any((A[i] <= 10.0) & (fam != fam[i])) for i in range(len(P))])
    return cusp, trans


def designs():
    out = {}
    for m in C.METHODS:
        for s in C.STARTS:
            d = json.load(open(HERE / "runs" / m / f"s{s}" / "design.json")); out[(m, s)] = (np.array(d["directions"]), np.array(d["radii"]), d["keyhashes"])
    return out


def task(args):
    (m, s), (X, r, _), ref, cusp, trans = args; P = ref[["z1", "z2", "z3"]].to_numpy(); rr = ref.yield_radius.to_numpy(); A = (ref.set == "area").to_numpy()
    SW = ~A; rows, preds = [], []
    for sur, sch in SUR.items():
        for n in C.CHECKPOINTS:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, sch).fit(X[:n], r[:n])
            amp, ls, wn = g.theta(); mu, vl = g.predict_log(P); sd = np.sqrt(vl + wn); e = np.exp(mu) / rr - 1; ae = np.abs(e); z = (np.log(rr) - mu) / sd
            nf = A & ~cusp & ~trans
            rows.append(dict(method=m, start=s, surrogate=sur, n=n, area_mean=ae[A].mean(), area_rms=np.sqrt(np.mean(e[A] ** 2)), area_p95=np.percentile(ae[A], 95),
                             area_max=ae[A].max(), sweep_mean=ae[SW].mean(), sweep_max=ae[SW].max(), cusp_mean=ae[cusp].mean(), cusp_max=ae[cusp].max(),
                             trans_mean=ae[trans].mean(), trans_max=ae[trans].max(), nonfeature_mean=ae[nf].mean(), bias_log=float(np.mean(np.log(rr[A]) - mu[A])),
                             cov90=np.mean(np.abs(z[A]) <= 1.645), cov95=np.mean(np.abs(z[A]) <= 1.96), rms_z=np.sqrt(np.mean(z[A] ** 2)),
                             spearman_sd_vs_abs_log_err=stats.spearmanr(sd[A], np.abs(np.log(rr[A]) - mu[A])).correlation,
                             length_scale=ls, amplitude=amp, white_noise=wn, gp_mode=g.mode_, n_training=len(g.X_train_)))
            if n in (33, 64) or (sur == "A20" and n in (8, 16)):
                preds += [dict(method=m, start=s, surrogate=sur, n=n, ref_id=i, pred_r=float(np.exp(a)), sd_log=float(b), meas_r=float(c), err=float(d_))
                          for i, a, b, c, d_ in zip(ref.ref_id, mu, sd, rr, e)]
    return rows, preds


def signed_rank_exact(L):
    """exact two-sided Wilcoxon signed-rank p (no zeros expected; zeros dropped), Hodges-Lehmann estimate and exact ~95 % CI (Walsh averages)."""
    L = np.asarray(L, float); L = L[L != 0]; n = len(L)
    if n == 0:                                                                       # AMENDMENT 1: identical designs (e.g. n = 8, shared initial 8)
        return dict(n=0, T_plus=0.0, p_exact=1.0, HL=0.0, ci_lo=0.0, ci_hi=0.0, ci_conf=float("nan"), note="all paired differences zero")
    rk = stats.rankdata(np.abs(L)); Tp = rk[L > 0].sum()
    dist = np.array([sum(rk[np.array(sg, bool)]) for sg in itertools.product([0, 1], repeat=n)]); mean = n * (n + 1) / 4
    p = float(np.mean(np.abs(dist - mean) >= abs(Tp - mean) - 1e-12))
    W_ = np.sort([(L[i] + L[j]) / 2 for i in range(n) for j in range(i, n)]); M = len(W_)
    cdf = np.array([np.mean(dist <= t) for t in range(n * (n + 1) // 2 + 1)])
    if not np.any(cdf <= 0.025):                                                     # AMENDMENT 1: too few non-zero pairs for an exact 95 % CI
        return dict(n=n, T_plus=float(Tp), p_exact=p, HL=float(np.median(W_)), ci_lo=float(W_[0]), ci_hi=float(W_[-1]), ci_conf=float("nan"), note="full Walsh range")
    c = int(np.max(np.where(cdf <= 0.025)[0]))                                       # largest c with P(T+ <= c) <= 0.025 (n = 9: c = 5)
    # exact CI = [W_(c+1), W_(M-c)] (1-based) -> 0-based W_[c], W_[M-1-c]; achieved confidence 1 - 2 P(T+ <= c)  (n = 9: 96.1 %)
    return dict(n=n, T_plus=float(Tp), p_exact=p, HL=float(np.median(W_)), ci_lo=float(W_[c]), ci_hi=float(W_[M - 1 - c]), ci_conf=float(1 - 2 * cdf[c]))


def paired(M):
    rows = []
    for (sur, n), g in M.groupby(["surrogate", "n"]):
        for met in ("area_mean", "area_rms", "area_p95", "area_max", "sweep_mean", "sweep_max", "cusp_mean", "cusp_max", "trans_mean", "trans_max", "nonfeature_mean"):
            fam = []
            for a, b in (("V2", "AXMM"), ("V2", "RANDOM"), ("AXMM", "RANDOM")):
                ea = g[g.method == a].set_index("start")[met]; eb = g[g.method == b].set_index("start")[met]; ea, eb = ea.loc[list(C.STARTS)], eb.loc[list(C.STARTS)]
                L = np.log(eb.to_numpy() / ea.to_numpy())                                       # > 0  <=>  a better than b
                st = signed_rank_exact(L)
                fam.append(dict(surrogate=sur, n=n, metric=met, a=a, b=b, wins_a=int((L > 0).sum()), ratio_HL=float(np.exp(st["HL"])), ratio_ci_lo=float(np.exp(st["ci_lo"])),
                                ratio_ci_hi=float(np.exp(st["ci_hi"])), ci_conf=st["ci_conf"], p_exact=st["p_exact"], median_err_a=float(ea.median()), median_err_b=float(eb.median()),
                                median_diff_pp=float(np.median(eb.to_numpy() - ea.to_numpy()) * 100)))
            ps = np.array([x["p_exact"] for x in fam]); order = np.argsort(ps); adj = np.empty(3); run = 0
            for rank, i in enumerate(order):                                                   # Holm over the 3 comparisons of this (metric, n, surrogate) family
                run = max(run, min(1.0, (3 - rank) * ps[i])); adj[i] = run
            for x, q in zip(fam, adj):
                x["p_holm3"] = float(q)
            rows += fam
    return pd.DataFrame(rows)


def claims(PD):
    """PRIMARY (protocol 6): n = 33, area_mean, A20; family = {V2 vs AXMM, V2 vs RANDOM}, Holm over these 2."""
    out = {}
    prim = PD[(PD.surrogate == "A20") & (PD.n == 33) & (PD.metric == "area_mean") & (PD.a == "V2") & (PD.b.isin(["AXMM", "RANDOM"]))].copy()
    ps = prim.p_exact.to_numpy(); o = np.argsort(ps); adj = np.empty(len(ps)); run = 0
    for rank, i in enumerate(o):
        run = max(run, min(1.0, (len(ps) - rank) * ps[i])); adj[i] = run
    prim["p_holm2"] = adj
    for _, x in prim.iterrows():
        fx = PD[(PD.surrogate == "FIXED") & (PD.n == 33) & (PD.metric == "area_mean") & (PD.a == "V2") & (PD.b == x.b)].iloc[0]
        better = dict(holm=x.p_holm2 < 0.05, ci=x.ratio_ci_lo > 1.0, wins=x.wins_a >= 8, floor=x.median_diff_pp > DELTA_NUM_PP, fixed=(fx.wins_a >= 7 and fx.ratio_HL > 1.0))
        worse = dict(holm=x.p_holm2 < 0.05, ci=x.ratio_ci_hi < 1.0, wins=(9 - x.wins_a) >= 8, floor=-x.median_diff_pp > DELTA_NUM_PP, fixed=((9 - fx.wins_a) >= 7 and fx.ratio_HL < 1.0))
        verdict = ("V2 ADVANTAGE" if all(better.values()) else "V2 DISADVANTAGE" if all(worse.values()) else "NO SUPPORTED DIFFERENCE")
        out[f"V2_vs_{x.b}"] = dict(primary=dict(x), fixed_sensitivity=dict(fx), criteria_better=better, criteria_worse=worse, verdict=verdict,
                                   practically_meaningful=bool(verdict == "V2 ADVANTAGE" and x.ratio_HL >= 1.10))
    return out


def cost(des):
    rows = []; rec = {}
    for l in (HERE / "trials/index.jsonl").read_text().splitlines():
        x = json.loads(l); rec[x["keyhash"]] = json.loads((HERE / x["record"]).read_text())
    for (m, s), (X, r, keys) in des.items():
        info = json.load(open(HERE / "runs" / m / f"s{s}" / "run_info.json")); ctrl = info["controller_cpu_s"]
        cum = np.cumsum([rec[k]["cpu_s"] for k in keys]); per_step = ctrl / (C.BUDGET - C.N_INIT)
        for n in C.CHECKPOINTS:
            rows.append(dict(method=m, start=s, n=n, moose_cpu_h=cum[n - 1] / 3600, controller_cpu_h=per_step * max(0, n - C.N_INIT) / 3600,
                             total_cpu_h=(cum[n - 1] + per_step * max(0, n - C.N_INIT)) / 3600))
    return pd.DataFrame(rows)


def response_dependence(lib, des):
    """V2 driven by a CONSTANT response (no information; no MOOSE) from the same start: first divergence and overlap with the actual V2 design."""
    from yield_surface_discovery.oracle import YieldOracle, YieldObservation
    class Const(YieldOracle):
        def evaluate(self, d):
            d = np.asarray(d, float); return YieldObservation(requested_direction=d, achieved_direction=d, stress_at_yield=d, yield_radius=10.0)
        def evaluate_many(self, X):
            return [self.evaluate(x) for x in np.atleast_2d(X)]
    out = {}
    for s in C.STARTS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore"); c = C.W.V2Controller(lib, Const(), C.W.V2Settings(symmetry="none", schedule="A20", budget=64, record_scores=False)).run(s)["sequence"]
        v = json.load(open(HERE / "runs/V2" / f"s{s}" / "design.json"))["axes"]; a = json.load(open(HERE / "runs/AXMM" / f"s{s}" / "design.json"))["axes"]
        out[s] = dict(first_divergence_vs_constant=next((i + 1 for i, (x, y) in enumerate(zip(v, c)) if x != y), None), overlap33_const=len(set(v[:33]) & set(c[:33])),
                      overlap64_const=len(set(v) & set(c)), overlap33_axmm=len(set(v[:33]) & set(a[:33])), overlap64_axmm=len(set(v) & set(a)),
                      first_divergence_vs_axmm=next((i + 1 for i, (x, y) in enumerate(zip(v, a)) if x != y), None))
    return out


if __name__ == "__main__":
    import multiprocessing as mp, resource
    OUT.mkdir(exist_ok=True); t0 = time.process_time(); rc0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    ref = pd.read_csv(C.TREF_CSV); tab = pd.read_csv(C.T / "pilot/tl1_reference_table.csv").set_index("ref_id").loc[ref.ref_id].reset_index()
    for f in ("FH", "FI60", "FI120", "K0", "K60", "K120"):
        ref[f"share_{f}"] = tab[f"share_{f}"].to_numpy()
    cusp, trans = regions(ref); des = designs(); lib = C.library()
    with mp.Pool(8) as p:
        res = p.map(task, [(k, v, ref, cusp, trans) for k, v in des.items()])
    M = pd.DataFrame([r for rr, _ in res for r in rr]); Pr = pd.DataFrame([q for _, pp in res for q in pp])
    M.to_csv(OUT / "metrics.csv", index=False); Pr.to_csv(OUT / "predictions.csv", index=False)
    PD = paired(M); PD.to_csv(OUT / "paired.csv", index=False); CLM = claims(PD); (OUT / "claims.json").write_text(json.dumps(CLM, indent=1, default=float))
    cost(des).to_csv(OUT / "cost.csv", index=False); RD = response_dependence(lib, des); (OUT / "response_dependence.json").write_text(json.dumps(RD, indent=1))
    (OUT / "regions.json").write_text(json.dumps(dict(n_cusp=int(cusp.sum()), n_transition=int(trans.sum()), n_area=int((ref.set == "area").sum()),
                                                    cusp_ids=ref.ref_id[cusp].tolist(), transition_ids=ref.ref_id[trans].tolist()), indent=1))
    rc1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    C.ledger_add("evaluation", time.process_time() - t0 + (rc1.ru_utime - rc0.ru_utime) + (rc1.ru_stime - rc0.ru_stime), note="parent + pool workers")
    print(json.dumps({k: v["verdict"] for k, v in CLM.items()}), flush=True)
    print(M[(M.surrogate == "A20")].groupby(["method", "n"]).area_mean.median().unstack("method").mul(100).round(3).to_string())

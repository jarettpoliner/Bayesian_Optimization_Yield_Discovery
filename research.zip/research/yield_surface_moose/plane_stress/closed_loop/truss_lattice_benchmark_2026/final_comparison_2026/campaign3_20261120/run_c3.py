#!/usr/bin/env python3
"""Execute the frozen three-method TL1 comparison (PROTOCOL.md).  Order: initial designs -> AXMM + RANDOM (non-adaptive) -> frozen V2-A20.
    python -B run_c3.py baselines [workers]
    python -B run_c3.py v2 [workers]
Checkpoint: runs/<METHOD>/s<k>/run_info.json marks a finished campaign (skipped on re-run).  An unfinished directory is MOVED to
runs_incomplete/ (never deleted) and the campaign is re-run; every observation it already obtained is reused exactly from the trial store,
so the re-run is deterministic and costs no MOOSE time for those observations."""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, shutil, time, warnings
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import c3_common as C

RUNS = HERE / "runs"


def _prepare(method, s):
    out = RUNS / method / f"s{s}"
    if (out / "run_info.json").exists():
        return None
    if out.exists():
        dst = HERE / "runs_incomplete" / method / f"s{s}_{int(time.time())}"; dst.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(out), str(dst))
    out.mkdir(parents=True); return out


def _get(args):
    d, req = args; r = C.get(d, req); return r["keyhash"], bool(r.get("accepted") and r.get("valid")), r.get("yield_radius"), r.get("cpu_s", 0.0)


def baselines(workers):
    lib = C.library(); D = lib.directions
    # 1. initial designs (shared by all three methods)
    jobs = {}
    for s in C.STARTS:
        for c in C.initial_design(lib, s):
            jobs.setdefault(c, (D[c], f"INIT_s{s}"))
    with ProcessPoolExecutor(workers) as ex:
        res = dict(zip(jobs, ex.map(_get, jobs.values())))
    bad = [c for c, r in res.items() if not r[1]]
    if bad:
        raise SystemExit(f"STOP (protocol 5.3): initial-design trial(s) not accepted: {bad}")
    # 2. AXMM and RANDOM orders; run the first BUDGET of each order in parallel, then spares sequentially for any rejected trial
    orders = {("AXMM", s): C.maximin_order(lib, s) for s in C.STARTS}; orders.update({("RANDOM", s): C.random_order(lib, s) for s in C.STARTS})
    for (m, s), o in orders.items():
        assert o[:C.N_INIT] == C.initial_design(lib, s), f"{m} s{s}: first 8 must equal the shared initial design"
    first = {}
    for (m, s), o in orders.items():
        for c in o[:C.BUDGET]:
            first.setdefault(c, (D[c], f"{m}_s{s}"))
    with ProcessPoolExecutor(workers) as ex:
        res.update(dict(zip(first, ex.map(_get, first.values()))))
    for (m, s), o in orders.items():
        out = _prepare(m, s)
        if out is None:
            continue
        t0 = time.process_time(); axes, radii, keys, failed, k = [], [], [], [], 0
        while len(axes) < C.BUDGET:
            if k >= len(o):
                raise SystemExit(f"STOP: {m} s{s} ran out of candidates")
            c = o[k]; k += 1
            if c not in res:
                res[c] = _get((D[c], f"{m}_s{s}"))
            kh, ok, r, _ = res[c]
            if ok:
                axes.append(int(c)); radii.append(float(r)); keys.append(kh)
            else:
                failed.append(int(c))
        assert len(set(axes)) == C.BUDGET and axes[:C.N_INIT] == C.initial_design(lib, s)
        json.dump(dict(axes=axes, radii=radii, keyhashes=keys, failed=failed, directions=D[axes].tolist()), open(out / "design.json", "w"))
        cpu = time.process_time() - t0; C.ledger_add(f"controller:{m}_s{s}", cpu)
        json.dump(dict(method=m, start=s, budget=C.BUDGET, n_failed=len(failed), controller_cpu_s=cpu, oracle_id=C.ORACLE_ID,
                       rule="signed angular maximin, frozen V1 deterministic" if m == "AXMM" else "init 8 + default_rng(9000+s).permutation (unique signed)",
                       frozen=C.W.check_frozen()), open(out / "run_info.json", "w"), indent=1)
    print(f"baselines done; ledger {C.ledger_total() / 3600:.3f} CPU-h", flush=True)


def v2_campaign(s):
    out = _prepare("V2", s)
    if out is None:
        return f"V2 s{s} skipped (complete)"
    warnings.simplefilter("ignore"); lib = C.library(); orc = C.C3Oracle(f"V2_s{s}"); t0 = time.process_time()
    ctl = C.W.V2Controller(lib, orc, C.W.V2Settings(symmetry="none", schedule="A20", budget=C.BUDGET, record_scores=True))
    assert ctl.ax is None and len(ctl.C) == 8192 and ctl.initial_design(s) == C.initial_design(lib, s)
    res = ctl.run(s); cpu = time.process_time() - t0; seq = res["sequence"]
    assert len(seq) == C.BUDGET and len(set(seq)) == C.BUDGET and seq[:C.N_INIT] == C.initial_design(lib, s)
    st = [x for x in res["steps"] if "n_real" in x]; assert all(x["n_training_points"] == x["n_real"] for x in st), "pseudo-observations present"
    pd.DataFrame([{k: v for k, v in x.items() if k != "tie_set"} for x in res["steps"]]).to_csv(out / "steps.csv", index=False)
    np.save(out / "scores_f32.npy", np.array([np.where(np.isfinite(x), x, np.nan) for x in res["scores"]], np.float32))
    keys = [o.metadata["keyhash"] for o in res["observations"]]
    json.dump(dict(axes=[int(c) for c in seq], radii=[float(o.yield_radius) for o in res["observations"]], keyhashes=keys,
                   failed=[x["candidate"] for x in res["steps"] if "event" in x], directions=lib.directions[seq].tolist()), open(out / "design.json", "w"))
    C.ledger_add(f"controller:V2_s{s}", cpu)
    json.dump(dict(method="V2", start=s, budget=C.BUDGET, oracle_calls=orc.calls, controller_cpu_s=cpu, settings=res["settings"], oracle_id=C.ORACLE_ID,
                   frozen=C.W.check_frozen()), open(out / "run_info.json", "w"), indent=1, default=str)
    return f"V2 s{s} done: controller {cpu:.1f} CPU-s, ledger {C.ledger_total() / 3600:.3f} CPU-h"


if __name__ == "__main__":
    what = sys.argv[1]; workers = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    if C.foreign_moose():
        raise SystemExit(f"GUARD: foreign MOOSE running {C.foreign_moose()[:3]}")
    if what == "baselines":
        baselines(workers)
    elif what == "v2":
        with ProcessPoolExecutor(workers) as ex:
            for msg in ex.map(v2_campaign, C.STARTS):
                print(msg, flush=True)

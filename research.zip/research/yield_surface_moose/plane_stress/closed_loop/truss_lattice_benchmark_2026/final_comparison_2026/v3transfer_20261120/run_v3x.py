#!/usr/bin/env python3
"""Execute the V3 transfer extension (PROTOCOL.md): arms V3F (frozen V3) and V3S (V3-Signed), 9 matched starts, budget 64, signed TL1 library,
symmetry 'none' (signed GP, no pseudo-observations).   python -B run_v3x.py [workers]
Checkpoint: runs/<ARM>/s<k>/run_info.json = finished (skipped).  Unfinished directories are moved to runs_incomplete/ (never deleted); a re-run is
deterministic and reuses every observation already measured (own store, then the frozen campaign3 store, exact match)."""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, shutil, time, warnings
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import v3x_common as X


def campaign(job):
    arm, s = job; out = HERE / "runs" / arm / f"s{s}"
    if (out / "run_info.json").exists():
        return f"{arm} s{s} skipped (complete)"
    if out.exists():
        dst = HERE / "runs_incomplete" / arm / f"s{s}_{int(time.time())}"; dst.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(out), str(dst))
    out.mkdir(parents=True); warnings.simplefilter("ignore"); lib = X.library(); orc = X.XOracle(f"{arm}_s{s}"); t0 = time.process_time()
    ctl = X.controller(arm, lib, orc)
    assert ctl.ax is None and len(ctl.C) == 8192 and ctl.initial_design(s) == X.initial_design(lib, s)
    res = ctl.run(s); cpu = time.process_time() - t0; seq = res["sequence"]
    assert len(seq) == X.BUDGET and len(set(seq)) == X.BUDGET and seq[:X.N_INIT] == X.initial_design(lib, s)
    st = [x for x in res["steps"] if "n_real" in x]; assert all(x["n_training_points"] == x["n_real"] for x in st), "pseudo-observations present"
    pd.DataFrame([{k: v for k, v in x.items() if k != "tie_set"} for x in res["steps"]]).to_csv(out / "steps.csv", index=False)
    np.save(out / "scores_f32.npy", np.array([np.where(np.isfinite(x), x, np.nan) for x in res["scores"]], np.float32))
    json.dump(dict(axes=[int(c) for c in seq], radii=[float(o.yield_radius) for o in res["observations"]], keyhashes=[o.metadata["keyhash"] for o in res["observations"]],
                   failed=[x["candidate"] for x in res["steps"] if "event" in x], directions=lib.directions[seq].tolist()), open(out / "design.json", "w"))
    X.ledger_add(f"controller:{arm}_s{s}", cpu)
    json.dump(dict(arm=arm, start=s, budget=X.BUDGET, version=res["version"], oracle_calls=orc.calls, controller_cpu_s=cpu, settings=res["settings"],
                   oracle_id=X.ORACLE_ID, frozen_v3_sha256=X.C3.sha(Path(X.V3.__file__)), v3s_sha256=X.C3.sha(Path(X.V3S.__file__)), frozen=X.W.check_frozen()),
              open(out / "run_info.json", "w"), indent=1, default=str)
    return f"{arm} s{s} done: controller {cpu:.1f} CPU-s, ledger {X.ledger_total() / 3600:.3f} CPU-h"


if __name__ == "__main__":
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 9
    if X.foreign_moose():
        raise SystemExit(f"GUARD: foreign MOOSE {X.foreign_moose()[:3]}")
    jobs = [(a, s) for s in X.STARTS for a in X.ARMS]
    with ProcessPoolExecutor(workers) as ex:
        for msg in ex.map(campaign, jobs):
            print(msg, flush=True)

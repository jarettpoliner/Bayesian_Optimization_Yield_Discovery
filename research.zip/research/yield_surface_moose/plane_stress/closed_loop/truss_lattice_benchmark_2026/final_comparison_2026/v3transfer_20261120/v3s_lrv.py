"""V3-Signed (VERSION v3.0-LRV-S1): a separately versioned, EXPLORATORY amendment of the frozen V3 LRV acquisition for signed loading directions.
The frozen V3 (closed_loop/response_adaptive_v3_2026/v3_lrv.py, sha256 6eaba9e5...) is imported read-only and NOT modified.

Exactly two mathematical changes relative to frozen V3 (everything else is imported or copied verbatim):
  1. LOO-risk interpolation weights:  c_i(x) = max( m(x, x_i), m(x, -x_i) )   ->   c_i(x) = m(x, x_i)
     (m = Matern nu = 1.5, length RISK_LENGTH = 0.5, unchanged).  With signed directions -x_i is a different, unobserved experiment.
  2. Failure repair of the initial design: bomes_v2.axial_maximin (axial distance, d == -d)  ->  V1 angular_maximin (signed atan2 angle),
     i.e. exactly what the frozen V2Controller.run does when symmetry != 'antipodal'.  Only reached if an initial test fails.
Unchanged: GP (frozen GPv2 via V2Controller.fit: Matern-3/2, A20 schedule, bounds, restarts, held hyper-parameters), closed-form block-LOO
(V3.loo_standardised; in signed mode every block is the single observation, verified), normalisation rho <- rho / mean(u^2), floors and
fallback, score sigma_n^2(x) * rho_n(x), deterministic ties, exclusions, budget handling, step records.
`V3SController.run` is a verbatim copy of frozen `V3Controller.run` with the two changes marked "# S1"; with risk_fn = frozen V3.risk it
reproduces frozen V3 bitwise (tested in preflight_v3x.py)."""
import sys
from dataclasses import asdict
from pathlib import Path
import numpy as np
from sklearn.gaussian_process.kernels import Matern

CL = Path(__file__).resolve().parents[3]
for p in (str(CL / "v2"), str(CL / "response_adaptive_v3_2026")):
    if p not in sys.path:
        sys.path.insert(0, p)
import v3_lrv as V3                                                                  # noqa: E402  frozen V3 (read-only)
from v3_lrv import loo_standardised, entropy, select                                # noqa: E402  frozen
from yield_surface_discovery.initialization import angular_maximin                  # noqa: E402  frozen V1
VERSION = "v3.0-LRV-S1"
RISK_LENGTH = V3.RISK_LENGTH                                                         # 0.5, unchanged
assert RISK_LENGTH == 0.5


def risk_signed(gp, cand, u):
    """S1 change 1: rho_n over SIGNED candidates with c_i(x) = m(x, x_i).  Normalisation, floors and fallback identical to V3.risk."""
    u2 = u ** 2; m2 = float(np.mean(u2)) if len(u2) else np.nan
    if not np.all(np.isfinite(u2)) or not np.isfinite(m2) or m2 <= 1e-300:
        return np.ones(len(cand)), True
    k = Matern(RISK_LENGTH, "fixed", nu=1.5); D = gp.d_obs_
    c = k(cand, D); rho = (c @ u2) / c.sum(1) / m2
    return np.maximum(rho, 1e-12), False


class V3SController(V3.V3Controller):
    """frozen V3Controller with the two S1 changes.  risk_fn is a hook so that the copy can be verified against frozen V3 bitwise."""
    risk_fn = staticmethod(risk_signed)

    def run(self, start=0):
        s = self.s; seq, obs, steps, scores, unavailable = [], [], [], [], set()
        pending = self.initial_design(start)
        while pending:                                                               # identical to V2Controller.run
            for c, o in zip(pending, self.oracle.evaluate_many(self.C[pending])):
                if self._ok(o):
                    seq.append(c); obs.append(o)
                else:
                    unavailable.add(c); steps.append(dict(test_number=len(seq) + 1, event="failed initial test", candidate=c))
            if len(seq) >= s.n_initial:
                break
            ext = angular_maximin(self.C, seq, s.n_initial, "deterministic", s.maximin_tol_rad, unavailable)   # S1 change 2 (signed repair)
            pending = [i for i in ext if i not in seq]
        while len(seq) < s.budget:
            gp = self.fit(self.C[seq], [o.yield_radius for o in obs])
            mean, var = gp.predict_log(self.C)
            if self.uniform_risk:
                u = np.ones(len(seq)); rho, fb = np.ones(len(self.C)), False
            else:
                u = loo_standardised(gp); rho, fb = self.risk_fn(gp, self.C, u)                                # S1 change 1 (via hook)
            sc = var * rho; sc[seq] = -np.inf; sc[list(unavailable)] = -np.inf
            v2 = var.copy(); v2[seq] = -np.inf; v2[list(unavailable)] = -np.inf
            j, tied = select(sc, "deterministic", s.tie_rel, s.tie_abs); jm, _ = select(v2, "deterministic", s.tie_rel, s.tie_abs); hp = gp.hyperparameters()
            step = dict(test_number=len(seq) + 1, candidate=int(j), mes_candidate=int(jm), differs_from_mes=bool(j != jm), latent_var=float(var[j]),
                        rho=float(rho[j]), rho_min=float(rho[np.isfinite(sc)].min()), rho_max=float(rho[np.isfinite(sc)].max()), u_abs_max=float(np.abs(u).max()),
                        u_rms=float(np.sqrt(np.mean(u ** 2))), fallback=bool(fb), score=float(sc[j]), entropy=float(entropy(var[j])),
                        gp_mean_log_radius=float(mean[j]), tie_set_size=int(len(tied)), **{k: v for k, v in hp.items()})
            if s.record_scores:
                scores.append(sc.copy())
            o = self.oracle.evaluate(self.C[j])
            if not self._ok(o):
                unavailable.add(j); step["event"] = "failed test (axis marked unavailable)"; steps.append(step); continue
            seq.append(int(j)); obs.append(o); steps.append(step)
        return dict(start=start, sequence=seq, observations=obs, steps=steps, scores=scores, settings=asdict(s), version=VERSION, uniform_risk=self.uniform_risk)

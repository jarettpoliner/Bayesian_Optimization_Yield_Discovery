# TL1 V3 physical transfer validation: preregistered protocol (v3transfer_20261120)

**Freeze.** This file, `v3s_lrv.py`, `v3x_common.py`, `run_v3x.py`, `evaluate_v3x.py`, `preflight_v3x.py` and the passing preflight record are hashed in `PROTOCOL.sha256` **before any MOOSE run of this extension**. Later changes are documented amendments, with the originals kept.

**Untouched (read-only).** Frozen V3 (`response_adaptive_v3_2026/v3_lrv.py`, sha256 6eaba9e5…) and H1; the completed campaign3 (V2, AXMM and RANDOM campaigns, protocol, evaluation, reports, figures, trial store); B1/B2; the releases.

## 1. Arms

| Arm | Status | Definition |
|---|---|---|
| **V3F** (frozen V3) | **Transfer test (confirmatory)** | Frozen `V3Controller` with `V2Settings(symmetry='none', schedule='A20', budget=64)`. **Signed GP**, 8,192 distinct signed candidates, no pseudo-observations, separate MOOSE measurements for d and −d. The LOO-risk weighting stays the frozen c_i(x) = max(m(x, x_i), m(x, −x_i)) |
| **V3S** (V3-Signed, v3.0-LRV-S1) | **Exploratory amendment** | `v3s_lrv.V3SController`. Exactly two changes: c_i(x) = m(x, x_i), and signed angular-maximin failure repair. GP, kernel, A20 schedule, LOO residuals, normalisation, floors, ties and score σ²ₙρₙ are unchanged |

**Documented symmetry mismatch (Arm A).**
- Frozen ρₙ is exactly antipodally symmetric: ρ(d) = ρ(−d) (Stage 1, P4c). So each observation's LOO risk is also assigned to its unobserved antipode.
- TL1 is **not** antipodally symmetric: tension/compression asymmetry 0.26%, above the 0.2% limit.
- Arm A therefore tests the transfer of the frozen heuristic **as is**. It makes no claim that TL1 is symmetric.
- Its axial failure repair is never reached here: the initial 8 are the campaign3 observations, all valid.

**V3S verification (preflight P3, all required):**
- (a) with the frozen risk plugged in, V3S reproduces frozen V3 bitwise, both on the saved DBU r00 benchmark (antipodal) and on signed TL1;
- (b) `uniform_risk` reduces V3S to frozen V2 bitwise;
- (c) the signed ρ equals a brute-force evaluation (≤ 1e-10); it is not antipodally symmetric, while the frozen ρ is exactly;
- (d) V3S repairs a failed initial test exactly as V2 does in signed mode;
- (e) the LOO residuals equal a brute-force refit.

## 2. Matching and fixed inputs

- **Starts:** s = 0–8, the same as campaign3.
- **Initial 8:** identical to campaign3's (asserted).
- **Budget:** 64; n = 33 is a checkpoint of the same campaign.
- **Inputs:** TLIB-4096 v1 (8,192 signed directions), the TL1 MOOSE oracle with ORACLE_ID equal to campaign3's, and the Levin 1e-4 criterion.
- **Reuse:** exact (ORACLE_ID, signed key) matches, from this extension's store first, then the frozen campaign3 store (read-only).
- **References:** TREF (482) is used by `evaluate_v3x.py` only. It is never in either store and never read by controller code.
- **Comparators:** the frozen campaign3 V2, AXMM and RANDOM designs, re-evaluated with the identical evaluator. Their metrics must equal campaign3's `metrics.csv` exactly; this is reported.

## 3. Execution, validity, cost

- **Cap:** incremental **4 CPU-h HARD cap** for this extension, covering MOOSE, controllers, evaluation, figures, audit and preflight. Its own ledger never reads or resets campaign3's 3.24 CPU-h.
- **Launch gate:** a MOOSE launch is refused if the ledger + 135 s in-flight allowance + 0.30 CPU-h reserve would exceed 4 CPU-h.
- **Projected need:** ≤ 1,008 new runs × P95 10.5 s ≈ 2.93 CPU-h, plus controllers 0.10, evaluation/figures/audit 0.30 and preflight 0.05 = **3.38 CPU-h at P95 (margin 0.62 CPU-h)**. Expected with mean cost and reuse: about 2.5.
- **Stops:**
  - **numerical validity:** an accepted-but-invalid trial (equilibrium ≤ 1e-6, direction error ≤ 1e-3°, periodicity ≤ 1e-8, no failed steps) **stops** the run;
  - more than 2% failed trials stops the run;
  - a foreign MOOSE process stops new launches.
- **Checkpoints:** completed campaigns are skipped; incomplete ones are moved aside and re-run deterministically with reuse (P7).

## 4. Endpoints and statistics (evaluator identical to campaign3)

**Reconstruction GP:** frozen GPv2 (Matérn-3/2, no symmetry) at n = 8, 16, 33 and 64. A20 is primary; FIXED (ℓ = 0.5) is the sensitivity surrogate.

**PRIMARY endpoint:** n = 33, A20, mean |r̂/r − 1| over the 338 area-uniform references (area-weighted).

**Secondary endpoints:**
- n = 64;
- area max and P95;
- cusp region (34 references within 15° of ±equal-biaxial);
- transition region (127 references);
- sweeps;
- 90% and 95% coverage;
- CPU cost.

**Paired tests:**
- L_s = log(err_b / err_a) over the 9 starts;
- exact Wilcoxon signed-rank test;
- Hodges-Lehmann ratio with exact CI (96.1%);
- wins.

**Confirmatory family (Arm A):** {V3F vs AXMM, V3F vs V2} at the primary endpoint, Holm over 2.

**Exploratory family (Arm B):** {V3S vs AXMM, V3S vs V2} at the primary endpoint, Holm over 2. **Exploratory: no confirmatory claim.**

**Decision for "X ADVANTAGE over Y"** (same as campaign3); all must hold:
1. Holm p < 0.05;
2. CI lower bound > 1;
3. ≥ 8/9 wins;
4. median paired reduction > 0.13 pp;
5. FIXED sensitivity in the same direction (≥ 7/9 wins and HL > 1).

The mirror criteria define DISADVANTAGE. Anything else is NO SUPPORTED DIFFERENCE. **Practically meaningful** additionally requires HL ≥ 1.10.

**Secondary, descriptive:** {V3F, V3S} × {V2, AXMM, RANDOM} plus V3S vs V3F, for every metric, n and surrogate, with Holm over these 7 per family.

**Diagnostics (descriptive, no claims):**
- **Frozen vs signed risk weighting:** at every GP state of both arms (reconstructed from the data; it must reproduce the actual choice), the share of states where the two weightings pick different experiments, the correlation of log ρ, and ρ at the antipodes of observations.
- **Response ablation of selections:** both arms driven by isotropic von Mises radii (no MOOSE), giving selection overlap and first divergence. Because these designs are not re-observed, no error claim can come from this. **The V3_ISO limitation from H1 stands:** an advantage would not by itself show material-response adaptation.

**Scope:** one deterministic RVE and 9 matched starts.

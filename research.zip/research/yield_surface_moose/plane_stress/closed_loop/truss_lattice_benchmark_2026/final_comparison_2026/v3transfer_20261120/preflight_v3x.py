#!/usr/bin/env python3
"""Read-only preflight of the V3 physical transfer extension (NO MOOSE).  python -B preflight_v3x.py  -> preflight/preflight_<ts>.json
P1 source integrity  P2 original V3 regression replay  P3 V3-Signed correctness (faithful copy, reduction, signed formula, repair)
P4 reference leakage  P5 matched starts  P6 cost vs incremental 4 CPU-h cap  P7 checkpoint/recovery + hard cap (sandbox)  P8 guard
Stand-in responses in P3/P7 = exact TL1 first-yield polytope from the MOOSE influence matrix (NOT observations)."""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, subprocess, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import v3x_common as X
C3 = X.C3; V3 = X.V3; V3S = X.V3S; W = X.W; T = C3.T; V3D = C3.CL / "response_adaptive_v3_2026"
from yield_surface_discovery.oracle import AnalyticalOracle, YieldOracle, YieldObservation
OUT = HERE / "preflight"; OUT.mkdir(exist_ok=True); R = {}
sha = C3.sha
# ---------------- P1
man = dict(l.split("  ", 1)[::-1] for l in (T / "manifests/MANIFEST_truss.sha256").read_text().splitlines())
c3man = subprocess.run(["sha256sum", "--quiet", "-c", "MANIFEST.sha256"], cwd=X.C3D, capture_output=True, text=True)
c3prot = {f: sha(X.C3D / f) == h for h, f in [l.split() for l in (X.C3D / "PROTOCOL.sha256").read_text().splitlines()] if f != "evaluate_c3.py"}
R["P1_integrity"] = dict(v3_protocol_files={f: sha(V3D / f) == h for h, f in [l.split() for l in open(V3D / "PROTOCOL.sha256")]},
                         v3_h1_protocol_rc=subprocess.run(["sha256sum", "--quiet", "-c", "PROTOCOL.sha256"], cwd=V3D / "holdout_h1_2026", capture_output=True).returncode,
                         v2_v1=bool(W.check_frozen()), tl1={f: man.get(f) == sha(T / f) for f in C3.ORACLE_FILES + ["library/TLIB4096_v1.csv", "library/TREF_v1.csv"]},
                         campaign3_manifest_rc=c3man.returncode, campaign3_manifest_failures=c3man.stdout[-500:], campaign3_protocol_files=c3prot,
                         campaign3_amendment_rc=subprocess.run(["sha256sum", "--quiet", "-c", "amendments/AMENDMENT_1.sha256"], cwd=X.C3D, capture_output=True).returncode)
# known, explained campaign3 exception: audit/audit_stdout_final.txt was hashed by audit_c3.py while its own stdout redirect was still being
# written (same mtime as MANIFEST.sha256); it is a console log, not data.  Every other campaign3 entry must verify.
fails = [l.split(":")[0] for l in c3man.stdout.splitlines() if l.endswith("FAILED")]
p = R["P1_integrity"]; p["campaign3_manifest_failed_files"] = fails; p["campaign3_manifest_only_known_exception"] = fails in ([], ["audit/audit_stdout_final.txt"])
p["pass_"] = bool(all(p["v3_protocol_files"].values()) and p["v3_h1_protocol_rc"] == 0 and all(p["tl1"].values()) and p["campaign3_manifest_only_known_exception"]
                                          and all(c3prot.values()) and p["campaign3_amendment_rc"] == 0)
print("P1", p["pass_"], p["campaign3_manifest_rc"], flush=True)
# ---------------- P2 original V3 replay (+ P3a faithful copy on the same benchmark)
sys.path.insert(0, str(V3D)); sys.path.insert(0, str(V3D / "holdout_h1_2026"))
import run_v3 as RV, run_h1 as RH
def bitwise(res, saved_dir):
    saved = json.load(open(saved_dir / "design.json")); sc = np.load(saved_dir / "scores_f32.npy")
    mine = np.array([np.where(np.isfinite(x), x, np.nan) for x in res["scores"]], np.float32)
    return bool(res["sequence"] == saved["axes"] and [o.yield_radius for o in res["observations"]] == saved["radii"] and np.array_equal(mine, sc, equal_nan=True))
rep = {}
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    k, s, b, _ = RV.spec("dbu", 0); F = RV.S.LSF(k)
    for arm, fn in (("V3", F.radius), ("V3_ABL", F.base_radius)):
        rep[f"DBU_r00_{arm}"] = bitwise(V3.V3Controller(RV.C.library(), AnalyticalOracle(fn, "r"), RV.B.V2Settings(schedule="A20", symmetry="antipodal", budget=b)).run(s), V3D / f"runs/dbu/{arm}/r00")
    rec = RH.POP[0]; FH = RH.H.Yld91(rec)
    rep["H1_r00_V3"] = bitwise(V3.V3Controller(RH.C.library(), AnalyticalOracle(FH.radius, "r"), RH.B.V2Settings(schedule="A20", symmetry="antipodal", budget=64)).run(rec["start"]), V3D / "holdout_h1_2026/runs/V3/r00")
    c = V3S.V3SController(RV.C.library(), AnalyticalOracle(F.radius, "r"), RV.B.V2Settings(schedule="A20", symmetry="antipodal", budget=b)); c.risk_fn = V3.risk
    faithful_dbu = bitwise(c.run(s), V3D / "runs/dbu/V3/r00")
R["P2_v3_replay"] = dict(rep, pass_=all(rep.values()))
print("P2", R["P2_v3_replay"], flush=True)
# ---------------- P3 V3-Signed correctness on the signed TL1 library (stand-in responses)
lib = C3.library(); D = lib.directions; N = len(D); anti = np.r_[np.arange(N // 2, N), np.arange(N // 2)]
S = np.asarray(C3.CAL["Sbar"]); r_proxy = lambda X_: (C3.TO.SY[None, :] / np.abs(np.atleast_2d(X_) @ S.T)).min(1)
class Proxy(YieldOracle):
    def __init__(self, fail=()):
        self.fail = {tuple(np.round(D[i], 12)) for i in fail}
    def evaluate(self, d):
        d = np.asarray(d, float); bad = tuple(np.round(d, 12)) in self.fail; r = float("nan") if bad else float(r_proxy(d)[0])
        return YieldObservation(requested_direction=d, achieved_direction=d, stress_at_yield=r * d * np.array([1, 1, 1 / np.sqrt(2)]), yield_radius=r,
                                success=not bad, status="rejected" if bad else "ok")
    def evaluate_many(self, X_):
        return [self.evaluate(x) for x in np.atleast_2d(X_)]
P3 = {}
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    st = lambda b: W.V2Settings(symmetry="none", schedule="A20", budget=b)
    f = V3.V3Controller(lib, Proxy(), st(36)).run(0); c = V3S.V3SController(lib, Proxy(), st(36)); c.risk_fn = V3.risk; g = c.run(0)
    P3["a_faithful_copy"] = dict(dbu_antipodal_vs_saved_V3=faithful_dbu, tl1_signed_vs_frozen_V3=bool(f["sequence"] == g["sequence"] and all(np.array_equal(x, y) for x, y in zip(f["scores"], g["scores"]))))
    u2 = V3S.V3SController(lib, Proxy(), st(36), uniform_risk=True).run(0); v2 = W.V2Controller(lib, Proxy(), st(36)).run(0)
    P3["b_reduction_uniform_risk_equals_V2"] = bool(u2["sequence"] == v2["sequence"] and all(np.array_equal(x, y) for x, y in zip(u2["scores"], v2["scores"])))
    seq = v2["sequence"]; gp = W.B.GPv2(W.B.NO_SYMMETRY, W.B.SCHEDULES["A20"]).fit(D[seq[:33]], r_proxy(D[seq[:33]])); u = V3.loo_standardised(gp)
    rs, _ = V3S.risk_signed(gp, D, u); rf, _ = V3.risk(gp, D, u)
    from sklearn.gaussian_process.kernels import Matern
    mk = Matern(0.5, "fixed", nu=1.5); brute = np.array([sum(mk(D[i:i + 1], gp.d_obs_[j:j + 1])[0, 0] * u[j] ** 2 for j in range(len(u))) /
                                                          sum(mk(D[i:i + 1], gp.d_obs_[j:j + 1])[0, 0] for j in range(len(u))) for i in range(0, N, 97)]) / np.mean(u ** 2)
    P3["c_signed_formula"] = dict(max_rel_err_vs_bruteforce=float(np.max(np.abs(rs[::97] - np.maximum(brute, 1e-12)) / np.maximum(brute, 1e-12))),
                                  signed_rho_antipodal_max_abs_diff=float(np.max(np.abs(rs - rs[anti]))), frozen_rho_antipodal_max_abs_diff=float(np.max(np.abs(rf - rf[anti]))),
                                  rho_at_observed_equals_antipode_signed=bool(np.allclose(rs[seq[:33]], rs[anti[seq[:33]]])))
    init0 = C3.initial_design(lib, 0); bad = [init0[3]]
    rv2 = W.V2Controller(lib, Proxy(bad), st(10)).run(0); rs3 = V3S.V3SController(lib, Proxy(bad), st(10)).run(0); rf3 = V3.V3Controller(lib, Proxy(bad), st(10)).run(0)
    P3["d_failure_repair"] = dict(v3s_initial_equals_v2_signed_repair=rs3["sequence"][:8] == rv2["sequence"][:8], v3f_initial=rf3["sequence"][:8], v2_initial=rv2["sequence"][:8],
                                  v3f_uses_axial_repair=rf3["sequence"][:8] != rv2["sequence"][:8])
    gl = W.B.GPv2(W.B.NO_SYMMETRY, W.B.SCHEDULES["A20"]).fit(D[seq[:30]], r_proxy(D[seq[:30]])); ul = V3.loo_standardised(gl)
    from sklearn.gaussian_process import GaussianProcessRegressor
    Xt, Yt, a = gl.X_train_, gl.y_train_, gl.gp_.alpha; ub = []
    for i in range(len(Xt)):
        m = np.arange(len(Xt)) != i; gg = GaussianProcessRegressor(gl.gp_.kernel_, alpha=a, optimizer=None).fit(Xt[m], Yt[m]); mu, sd = gg.predict(Xt[i:i + 1], return_std=True)
        ub.append((Yt[i] - mu[0]) / np.sqrt(sd[0] ** 2 + a))
    P3["e_loo_signed_bruteforce_max_rel"] = float(np.max(np.abs(ul - np.array(ub))) / np.max(np.abs(ub)))
p = P3; P3["pass_"] = bool(p["a_faithful_copy"]["dbu_antipodal_vs_saved_V3"] and p["a_faithful_copy"]["tl1_signed_vs_frozen_V3"] and p["b_reduction_uniform_risk_equals_V2"]
                           and p["c_signed_formula"]["max_rel_err_vs_bruteforce"] < 1e-10 and p["c_signed_formula"]["signed_rho_antipodal_max_abs_diff"] > 1e-3
                           and p["c_signed_formula"]["frozen_rho_antipodal_max_abs_diff"] == 0.0 and p["d_failure_repair"]["v3s_initial_equals_v2_signed_repair"]
                           and p["e_loo_signed_bruteforce_max_rel"] < 1e-6)
R["P3_v3s"] = P3; print("P3", json.dumps(P3, default=str)[:900], flush=True)
# ---------------- P4 leakage
ref = pd.read_csv(C3.TREF_CSV); Pr = ref[["z1", "z2", "z3"]].to_numpy()
src = "".join((HERE / f).read_text() for f in ("v3x_common.py", "v3s_lrv.py", "run_v3x.py")) + (V3D / "v3_lrv.py").read_text()
R["P4_leakage"] = dict(min_angle_ref_to_candidate_deg=float(np.degrees(np.arccos(np.clip((Pr @ D.T).max(), -1, 1)))),
                       controller_code_mentions_TREF=any(t in src for t in ("TREF_CSV", "reference_results", "TREF_v1.csv", "refs_TREF")),
                       ref_keys_in_campaign3_store=len({C3.keyhash(q) for q in Pr} & {json.loads(l)["keyhash"] for l in (X.C3D / "trials/index.jsonl").read_text().splitlines()}))
R["P4_leakage"]["pass_"] = bool(R["P4_leakage"]["min_angle_ref_to_candidate_deg"] > 0.1 and not R["P4_leakage"]["controller_code_mentions_TREF"] and R["P4_leakage"]["ref_keys_in_campaign3_store"] == 0)
# ---------------- P5 matched starts
m5 = {}
for s in X.STARTS:
    v2init = json.load(open(X.C3D / f"runs/V2/s{s}/design.json"))["axes"][:8]
    m5[s] = bool(X.controller("V3F", lib, None).initial_design(s) == v2init == X.controller("V3S", lib, None).initial_design(s) == C3.initial_design(lib, s))
R["P5_matched_starts"] = dict(per_start=m5, pass_=all(m5.values()))
# ---------------- P6 cost
c3ref = pd.read_csv(C3.TREF_CSV); recs = [json.loads((X.C3D / json.loads(l)["record"]).read_text()) for l in (X.C3D / "trials/index.jsonl").read_text().splitlines()]
cpu = np.array([r["cpu_s"] for r in recs]); n_new_upper = 2 * 9 * 56
c3_led = sum(json.loads(l)["cpu_s"] for l in (X.C3D / "cpu_ledger.jsonl").read_text().splitlines()) / 3600
R["P6_cost"] = dict(campaign3_cpu_s_mean=float(cpu.mean()), campaign3_cpu_s_p95=float(np.percentile(cpu, 95)), new_moose_runs_upper=n_new_upper,
                    projected_moose_cpu_h_mean=n_new_upper * cpu.mean() * 1.05 / 3600, projected_moose_cpu_h_p95=n_new_upper * np.percentile(cpu, 95) / 3600,
                    projected_controllers_cpu_h=18 * 20 / 3600, projected_eval_figs_audit_cpu_h=0.30, preflight_charge_cpu_h=0.05, cap_cpu_h=4.0,
                    prior_campaign3_ledger_cpu_h_separate=c3_led)
c = R["P6_cost"]; c["projected_total_p95_cpu_h"] = c["projected_moose_cpu_h_p95"] + c["projected_controllers_cpu_h"] + c["projected_eval_figs_audit_cpu_h"] + c["preflight_charge_cpu_h"]
c["margin_cpu_h"] = 4.0 - c["projected_total_p95_cpu_h"]; c["pass_"] = bool(c["margin_cpu_h"] >= 0.5)
print("P4-6", R["P4_leakage"]["pass_"], R["P5_matched_starts"]["pass_"], json.dumps(c), flush=True)
# ---------------- P7 sandbox recovery + cap
calls = {"n": 0}
def fake_observe(d, wd, cal, **kw):
    calls["n"] += 1; Path(wd).mkdir(parents=True); r = float(r_proxy(np.asarray(d))[0])
    return dict(direction=list(d), accepted=True, crossed=True, yield_radius=r, stress_mandel=list(r * np.asarray(d)), equilibrium_rel_err_max=0.0,
                achieved_dir_err_deg=0.0, periodic_check=dict(rel=0.0), failed_steps=0, cpu_s=0.0, flags=[])
def sandbox(name):
    sb = OUT / f"sandbox_{name}_{time.strftime('%H%M%S')}"; sb.mkdir(); X.HERE = sb; X.TRIALS = sb / "trials"; X.INDEX = X.TRIALS / "index.jsonl"; X.LEDGER = sb / "cpu_ledger.jsonl"
    X.C3D = sb / "no_campaign3"                                                       # isolate from campaign3 reuse in the sandbox
real = X.TO.observe; X.TO.observe = fake_observe
class Crash(RuntimeError):
    pass
class Crashing(X.XOracle):
    def evaluate(self, d):
        if self.calls >= 15:
            raise Crash()
        return super().evaluate(d)
C3D_real = X.C3D
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    sandbox("a"); calls["n"] = 0; a = X.controller("V3S", lib, X.XOracle("a"), budget=26).run(0); na = calls["n"]
    sandbox("b"); calls["n"] = 0
    try:
        X.controller("V3S", lib, Crashing("b"), budget=26).run(0)
    except Crash:
        pass
    b = X.controller("V3S", lib, X.XOracle("b2"), budget=26).run(0)
    R["P7_recovery"] = dict(identical_sequence=a["sequence"] == b["sequence"], identical_scores=bool(all(np.array_equal(x, y) for x, y in zip(a["scores"], b["scores"]))),
                            runs_uninterrupted=na, runs_interrupted_plus_resume=calls["n"])
    sandbox("cap"); X.ledger_add("simulated", 3.9 * 3600)
    try:
        X.get(D[77], "cap"); R["P7_recovery"]["cap_raised"] = False
    except X.CapReached:
        R["P7_recovery"]["cap_raised"] = True
X.TO.observe = real
R["P7_recovery"]["pass_"] = bool(R["P7_recovery"]["identical_sequence"] and R["P7_recovery"]["identical_scores"] and R["P7_recovery"]["runs_interrupted_plus_resume"] == na and R["P7_recovery"]["cap_raised"])
R["P8_guard"] = dict(foreign=X.foreign_moose(), pass_=not X.foreign_moose())
R["ALL_PASS"] = all(v["pass_"] for v in R.values() if isinstance(v, dict) and "pass_" in v)
(OUT / f"preflight_{time.strftime('%Y%m%dT%H%M%S')}.json").write_text(json.dumps(R, indent=1, default=str))
print(json.dumps({k: (v.get("pass_") if isinstance(v, dict) else v) for k, v in R.items()}))

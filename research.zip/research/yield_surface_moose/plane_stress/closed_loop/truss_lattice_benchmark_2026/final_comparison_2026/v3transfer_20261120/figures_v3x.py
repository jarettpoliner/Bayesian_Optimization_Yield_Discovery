#!/usr/bin/env python3
"""Figures (SVG + PDF + PNG) for the V3 transfer extension, from the completed MOOSE campaigns and the frozen evaluation.
Measured MOOSE data are points; GP fields are labelled predictions.   python -B figures_v3x.py"""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, warnings
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, LogNorm, TwoSlopeNorm
from matplotlib.ticker import FuncFormatter, NullFormatter
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import v3x_common as X
EV = HERE / "evaluation"; FIG = HERE / "figures"; FIG.mkdir(exist_ok=True); B = X.W.B
METHODS = ("V3F", "V3S", "V2", "AXMM", "RANDOM")
MC = {"V3F": "#6250d6", "V3S": "#e87ba4", "V2": "#2a78d6", "AXMM": "#eb6834", "RANDOM": "#1baf7a"}
MN = {"V3F": "V3 frozen (transfer)", "V3S": "V3-Signed (exploratory)", "V2": "V2-A20 BO+MES", "AXMM": "angular maximin", "RANDOM": "random"}
SEQ = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#86b6ef", "#3987e5", "#256abf", "#184f95", "#0d366b"])
SEQV = LinearSegmentedColormap.from_list("seqv", ["#e3defa", "#b3a8f0", "#6250d6", "#43349e", "#251a63"])
SEQP = LinearSegmentedColormap.from_list("seqp", ["#fbe0ea", "#f2adc7", "#e87ba4", "#b9497a", "#7b2449"])
DIV = LinearSegmentedColormap.from_list("div", ["#184f95", "#3987e5", "#f0efec", "#eb6834", "#a8401a"])
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d4"
plt.rcParams.update({"font.size": 8.5, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.5, "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": "white", "axes.facecolor": "white",
                     "savefig.dpi": 200, "lines.linewidth": 1.6, "svg.fonttype": "none", "pdf.fonttype": 42})


def plainlog(ax, axis="both"):
    f = FuncFormatter(lambda v, _: f"{v:g}")
    for a in (["x", "y"] if axis == "both" else [axis]):
        ax_ = ax.xaxis if a == "x" else ax.yaxis; ax_.set_major_formatter(f); ax_.set_minor_formatter(NullFormatter())


def save(fig, name):
    for ext in ("svg", "pdf", "png"):
        fig.savefig(FIG / f"{name}.{ext}", bbox_inches="tight")
    plt.close(fig)


def eqarea(P):
    P = np.atleast_2d(P); up = P[:, 2] >= 0; Q = P * np.where(up, 1, -1)[:, None]; k = np.sqrt(2 / (1 + Q[:, 2]))
    return np.column_stack([np.where(up, -1.6, 1.6) + k * Q[:, 0], k * Q[:, 1]])


def disks(ax, label=True):
    for off, t in ((-1.6, "√2σxy ≥ 0"), (1.6, "√2σxy < 0")):
        ax.add_patch(plt.Circle((off, 0), np.sqrt(2), fill=False, color=INK2, lw=0.7))
        if label:
            ax.text(off, -1.62, t, ha="center", va="top", fontsize=7, color=INK2)
    ax.set_aspect("equal"); ax.set_xlim(-3.1, 3.1); ax.set_ylim(-1.85, 1.5); ax.axis("off")


rd = lambda m, s: (HERE / "runs" / m / f"s{s}") if m in X.ARMS else (X.C3D / "runs" / m / f"s{s}")
lib = X.library(); D = lib.directions; ref = pd.read_csv(X.C3.TREF_CSV)
M = pd.read_csv(EV / "metrics.csv"); PR = pd.read_csv(EV / "predictions.csv"); PD = pd.read_csv(EV / "paired.csv"); CO = pd.read_csv(EV / "cost.csv"); RW = pd.read_csv(EV / "risk_weighting.csv")
DES = {(m, s): json.load(open(rd(m, s) / "design.json")) for m in METHODS for s in X.STARTS}


def convergence():
    A = M[M.surrogate == "A20"]; fig, axs = plt.subplots(1, 4, figsize=(17, 3.9))
    for ax, met, lab in ((axs[0], "area_mean", "area-weighted mean |r̂/r − 1| (PRIMARY)"), (axs[1], "area_max", "max |r̂/r − 1| (area set)"),
                         (axs[2], "cusp_mean", "cusp region mean"), (axs[3], "trans_mean", "mechanism-transition region mean")):
        for m in METHODS:
            g = A[A.method == m]; md = g.groupby("n")[met].median() * 100
            q1 = g.groupby("n")[met].quantile(0.25) * 100; q3 = g.groupby("n")[met].quantile(0.75) * 100
            ax.fill_between(md.index, q1, q3, color=MC[m], alpha=0.10, lw=0); ax.plot(md.index, md.values, "-o", color=MC[m], ms=3.5, lw=1.8 if m in X.ARMS else 1.2,
                                                                                         ls="-" if m in X.ARMS else "--", label=MN[m])
        ax.set_xscale("log"); ax.set_yscale("log"); plainlog(ax); ax.set_xticks(X.CHECKPOINTS); ax.axvline(33, color=INK2, lw=0.8, ls=":")
        ax.set_xlabel("number of MOOSE experiments n"); ax.set_ylabel("[%]"); ax.set_title(lab, fontsize=8.5, loc="left")
    axs[0].legend(frameon=False, fontsize=7); fig.suptitle("Convergence on TL1 (median and inter-quartile band over 9 matched starts)", x=0.01, ha="left", fontsize=9.5)
    save(fig, "X01_convergence_all_methods")


def reconstructions():
    for sw, (e1, e2), lab in (("sweep_biax", ((1, 0, 0), (0, 1, 0)), "σxx–σyy plane"), ("sweep_eb_ps", ((1 / np.sqrt(2), 1 / np.sqrt(2), 0), (0, 0, 1)), "equal-biaxial → shear circle")):
        e1, e2 = np.array(e1, float), np.array(e2, float); nrm = np.cross(e1, e2); t = np.radians(np.arange(0, 360.01, 1.0)); G = np.cos(t)[:, None] * e1 + np.sin(t)[:, None] * e2
        R = ref[ref.set == sw]; rows = ("V3F", "V3S", "V2", "AXMM"); fig, axs = plt.subplots(len(rows), 4, figsize=(14, 9.6), sharex=True, sharey=True)
        for i, m in enumerate(rows):
            Xd = np.array(DES[(m, 0)]["directions"]); rr = np.array(DES[(m, 0)]["radii"])
            for j, n in enumerate(X.CHECKPOINTS):
                ax = axs[i, j]
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(Xd[:n], rr[:n])
                mu, vl = g.predict_log(G); sd = np.sqrt(vl + g.theta()[2])
                ax.fill_between(np.degrees(t), np.exp(mu - 1.96 * sd), np.exp(mu + 1.96 * sd), color=MC[m], alpha=0.15, lw=0, label="GP 95 % band (prediction)")
                ax.plot(np.degrees(t), np.exp(mu), color=MC[m], lw=1.3, label="GP mean (prediction)"); ax.scatter(R.sweep_t_deg, R.yield_radius, s=5, color=INK, zorder=3, label="MOOSE references (held out)")
                near = np.abs(np.degrees(np.arcsin(np.clip(Xd[:n] @ nrm, -1, 1)))) <= 4.0
                if near.any():
                    q = Xd[:n][near]; ax.scatter(np.degrees(np.arctan2(q @ e2, q @ e1)) % 360, rr[:n][near], s=24, marker="D", color=MC[m], edgecolor="white", lw=0.6, zorder=4,
                                                 label="campaign MOOSE obs. within 4°")
                if i == 0:
                    ax.set_title(f"n = {n}", fontsize=9)
                if j == 0:
                    ax.set_ylabel(f"{MN[m]}\nr [MPa]", fontsize=8)
                ax.set_xticks(range(0, 361, 90))
        for ax in axs[-1]:
            ax.set_xlabel("angle along the circle [deg]")
        h, l = axs[0, 3].get_legend_handles_labels(); fig.legend(h, l, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, -0.02))
        fig.suptitle(f"GP reconstructions (start 0) on the {lab} vs held-out MOOSE references", x=0.01, ha="left", fontsize=9.5); save(fig, f"X02_reconstruction_{sw}")


def selections():
    fig, axs = plt.subplots(2, 3, figsize=(13, 5.6))
    for c, (m, cm) in enumerate((("V3F", SEQV), ("V3S", SEQP), ("V2", SEQ))):
        E = eqarea(D[DES[(m, 0)]["axes"]]); ax = axs[0, c]
        ax.scatter(E[8:, 0], E[8:, 1], c=np.arange(9, 65), cmap=cm, s=16, edgecolor="white", lw=0.3, vmin=1, vmax=64)
        ax.scatter(E[:8, 0], E[:8, 1], s=30, facecolor="none", edgecolor=INK, lw=1.0, label="shared initial 8"); disks(ax); ax.set_title(f"{MN[m]}: start 0, tests 9–64 (shade = order)", fontsize=8.5)
        A = np.vstack([D[DES[(m, s)]["axes"][8:]] for s in X.STARTS]); E = eqarea(A); ax = axs[1, c]
        ax.scatter(E[:, 0], E[:, 1], s=4, color=MC[m], alpha=0.45, lw=0); disks(ax); ax.set_title(f"{MN[m]}: all 9 starts, tests 9–64", fontsize=8.5)
    axs[0, 1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.02), frameon=False, fontsize=7)
    fig.suptitle("Actual MOOSE loading-direction selections of both V3 arms (V2 for reference); signed directions, equal-area maps", x=0.01, ha="left", fontsize=9.5)
    save(fig, "X03_selections_v3")


def acquisition_maps():
    """predictive variance, LOO-risk rho and weighted score before (n = 32) and after (n = 33) the real 33rd experiment, both arms, start 0."""
    fig, axs = plt.subplots(4, 3, figsize=(14, 11))
    for a, arm in enumerate(X.ARMS):
        d = DES[(arm, 0)]; ax_ = d["axes"]; r = np.array(d["radii"])
        for b, n in enumerate((32, 33)):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(D[ax_[:n]], r[:n])
            _, var = g.predict_log(D); u = X.V3.loo_standardised(g); rho = (X.V3.risk if arm == "V3F" else X.V3S.risk_signed)(g, D, u)[0]; sc = var * rho
            msk = np.ones(len(D), bool); msk[ax_[:n]] = False; E = eqarea(D[msk]); O = eqarea(D[ax_[:n]]); nx = eqarea(D[[ax_[n]]])
            row = 2 * a + b
            for c, (vals, cm, norm, lab) in enumerate(((var, SEQ, LogNorm(*np.percentile(var[msk], [5, 100])), "GP latent variance σ²ₙ"),
                                                       (rho, DIV, TwoSlopeNorm(1.0, max(rho[msk].min(), 1e-3), max(rho[msk].max(), 1.01)), "LOO risk ρₙ (" + ("frozen, antipodal" if arm == "V3F" else "signed") + ")"),
                                                       (sc, SEQV if arm == "V3F" else SEQP, LogNorm(*np.percentile(sc[msk], [5, 100])), "acquisition σ²ₙ·ρₙ"))):
                ax = axs[row, c]; im = ax.scatter(E[:, 0], E[:, 1], c=vals[msk], cmap=cm, norm=norm, s=4, marker="h", lw=0, rasterized=True)
                ax.scatter(O[:, 0], O[:, 1], s=10, facecolor="white", edgecolor=INK, lw=0.5)
                if b == 0:
                    ax.scatter(nx[:, 0], nx[:, 1], s=70, marker="*", color="#eda100", edgecolor=INK, lw=0.5, zorder=5)
                disks(ax, label=False); fig.colorbar(im, ax=ax, fraction=0.03, pad=0.0).ax.tick_params(labelsize=6)
                ax.set_title(f"{MN[arm]}, {'before test 33 (n = 32)' if b == 0 else 'after test 33 (n = 33)'}: {lab}", fontsize=7.5)
    fig.suptitle("Variance, LOO risk and weighted acquisition on 8,192 signed candidates (start 0; ★ = the experiment actually run next; ○ = MOOSE observations)",
                 x=0.01, ha="left", fontsize=9.5)
    save(fig, "X04_acquisition_maps_before_after")


def paired():
    P = PD[(PD.surrogate == "A20") & (PD.metric == "area_mean") & (PD.n.isin([33, 64]))]; pairs = [("V3F", "AXMM"), ("V3F", "V2"), ("V3F", "RANDOM"), ("V3S", "AXMM"), ("V3S", "V2"), ("V3S", "RANDOM"), ("V3S", "V3F")]
    fig, ax = plt.subplots(figsize=(10, 4.6))
    for i, (a, b) in enumerate(pairs):
        for k, n in enumerate((33, 64)):
            x = P[(P.a == a) & (P.b == b) & (P.n == n)].iloc[0]; y = i * 3 + k
            ax.errorbar(x.ratio_HL, y, xerr=[[x.ratio_HL - x.ratio_ci_lo], [x.ratio_ci_hi - x.ratio_HL]], fmt="o" if n == 33 else "s", color=MC[a], ms=5, capsize=2, mfc=MC[a] if n == 33 else "white")
            ax.text(max(x.ratio_ci_hi, 1.0) * 1.02, y, f"n={n}: {int(x.wins_a)}/9, p(Holm,7)={x.p_holm7:.3f}", va="center", fontsize=6.5, color=INK2)
    ax.axvline(1, color=INK, lw=0.8); ax.set_xscale("log"); plainlog(ax, "x"); ax.set_xticks([0.7, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 2]); ax.set_xlim(0.65, 2.6)
    ax.set_yticks([i * 3 + 0.5 for i in range(len(pairs))]); ax.set_yticklabels([f"{MN[a]}\nvs {MN[b]}" for a, b in pairs], fontsize=7); ax.invert_yaxis()
    ax.set_xlabel("err(b) / err(a), Hodges–Lehmann with exact 96 % CI  (> 1: the V3 arm a is better)   ● n = 33   □ n = 64")
    ax.set_title("Paired comparisons over 9 matched starts, primary metric (descriptive Holm over 7 pairs)", fontsize=8.5, loc="left"); save(fig, "X05_paired_ratios")


def regional():
    mets = [("area_mean", "global"), ("cusp_mean", "cusp"), ("trans_mean", "transition"), ("nonfeature_mean", "non-feature"), ("area_max", "max")]
    fig, axs = plt.subplots(1, 2, figsize=(13, 3.6), sharey=True)
    for ax, n in zip(axs, (33, 64)):
        g = M[(M.surrogate == "A20") & (M.n == n)]; w = 0.16
        for j, m in enumerate(METHODS):
            med = [g[g.method == m][c].median() * 100 for c, _ in mets]; ax.bar(np.arange(len(mets)) + (j - 2) * w, med, width=w * 0.92, color=MC[m], label=MN[m])
        ax.set_xticks(range(len(mets))); ax.set_xticklabels([l for _, l in mets]); ax.set_yscale("log"); plainlog(ax, "y"); ax.set_title(f"n = {n}: median over starts [%]", fontsize=8.5, loc="left")
    axs[0].legend(frameon=False, fontsize=7, ncol=2); save(fig, "X06_regional_cusp_transition_errors")


def cpu():
    J = M[M.surrogate == "A20"].merge(CO, on=["method", "start", "n"]); fig, ax = plt.subplots(figsize=(6, 4))
    for m in METHODS:
        g = J[J.method == m]; md = g.groupby("n")[["total_cpu_h", "area_mean"]].median(); ax.scatter(g.total_cpu_h, g.area_mean * 100, s=8, color=MC[m], alpha=0.4, lw=0)
        ax.plot(md.total_cpu_h, md.area_mean * 100, "-o", color=MC[m], ms=3.5, label=MN[m])
    ax.set_xscale("log"); ax.set_yscale("log"); plainlog(ax); ax.set_xlabel("cumulative CPU-hours per campaign (MOOSE + controller)"); ax.set_ylabel("area-weighted mean error [%]")
    ax.legend(frameon=False, fontsize=7); ax.set_title("Error vs computational cost", fontsize=8.5, loc="left"); save(fig, "X07_error_vs_cpu")


def risk_compare():
    fig = plt.figure(figsize=(15.5, 7.6)); gs = fig.add_gridspec(2, 3, wspace=0.42)
    d = DES[("V3F", 0)]; ax_ = d["axes"]; r = np.array(d["radii"]); n = 32
    with warnings.catch_warnings():
        warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(D[ax_[:n]], r[:n])
    u = X.V3.loo_standardised(g); rf = X.V3.risk(g, D, u)[0]; rs = X.V3S.risk_signed(g, D, u)[0]; E = eqarea(D); O = eqarea(D[ax_[:n]])
    vmax = max(rf.max(), rs.max())
    for c, (vals, lab) in enumerate(((rf, "frozen ρ: c = max(m(x,xᵢ), m(x,−xᵢ))  — antipodally symmetric"), (rs, "signed ρ: c = m(x,xᵢ)"))):
        ax = fig.add_subplot(gs[0, c]); im = ax.scatter(E[:, 0], E[:, 1], c=vals, cmap=DIV, norm=TwoSlopeNorm(1.0, min(rf.min(), rs.min()), vmax), s=4, marker="h", lw=0, rasterized=True)
        ax.scatter(O[:, 0], O[:, 1], s=12, facecolor="white", edgecolor=INK, lw=0.5); disks(ax); ax.set_title(lab, fontsize=7.5)
    fig.colorbar(im, ax=fig.axes[1], fraction=0.035, pad=0.02).set_label("LOO risk ρₙ (1 = mean)")
    ax = fig.add_subplot(gs[0, 2]); ax.scatter(rs, rf, s=2, color=MC["V3F"], alpha=0.3, lw=0); lim = [min(rf.min(), rs.min()), vmax]; ax.plot(lim, lim, color=INK, lw=0.8)
    ax.set_xscale("log"); ax.set_yscale("log"); plainlog(ax); tk = [0.7, 0.8, 1, 1.25, 1.5, 1.8]; ax.set_xticks(tk); ax.set_yticks(tk)
    ax.set_xlabel("signed ρ"); ax.set_ylabel("frozen ρ"); ax.set_title("same GP state (V3F start 0, n = 32): 8,192 candidates", fontsize=7.5)
    ax = fig.add_subplot(gs[1, 0])
    for arm in X.ARMS:
        q = RW[RW.arm == arm].groupby("n").frozen_ne_signed.mean(); ax.plot(q.index, q.values * 100, color=MC[arm], label=f"states of {MN[arm]}")
    ax.set_xlabel("observations n"); ax.set_ylabel("% of starts where frozen and signed\nweighting choose different experiments"); ax.legend(frameon=False, fontsize=7); ax.set_ylim(0, 105)
    ax = fig.add_subplot(gs[1, 1])
    for arm in X.ARMS:
        q = RW[RW.arm == arm]; ax.hist(q.corr_rho, bins=30, color=MC[arm], alpha=0.6, label=MN[arm])
    ax.set_xlabel("correlation of log ρ (frozen vs signed) over candidates"); ax.set_ylabel("GP states"); ax.legend(frameon=False, fontsize=7)
    ax = fig.add_subplot(gs[1, 2])
    for arm in X.ARMS:
        q = RW[RW.arm == arm].groupby("n")[["rho_frozen_at_antipodes_of_obs", "rho_signed_at_antipodes_of_obs"]].median()
        ax.plot(q.index, q.rho_frozen_at_antipodes_of_obs, color=MC[arm], label=f"frozen ρ at antipodes ({arm} states)"); ax.plot(q.index, q.rho_signed_at_antipodes_of_obs, color=MC[arm], ls="--", label=f"signed ρ ({arm})")
    ax.set_xlabel("observations n"); ax.set_ylabel("median ρ at the antipodes of observed directions"); ax.legend(frameon=False, fontsize=6.5)
    fig.suptitle("Frozen (antipodal) vs signed LOO-risk weighting on the real V3 GP states", x=0.01, ha="left", fontsize=9.5); save(fig, "X08_frozen_vs_signed_risk")


def calibration():
    fig, axs = plt.subplots(2, 5, figsize=(17, 6.6), sharex="row", sharey="row")
    for c, m in enumerate(METHODS):
        q = PR[(PR.surrogate == "A20") & (PR.n == 33) & (PR.method == m) & PR.ref_id.isin(ref.ref_id[ref.set == "area"])]; ae = np.abs(np.log(q.pred_r / q.meas_r))
        ax = axs[0, c]; ax.scatter(q.sd_log, ae, s=2, color=MC[m], alpha=0.35, lw=0); xx = np.linspace(0, q.sd_log.max(), 10); ax.plot(xx, 1.96 * xx, color=INK, lw=0.8, ls="--")
        g = M[(M.surrogate == "A20") & (M.n == 33) & (M.method == m)]; ax.set_title(f"{MN[m]}\ncov95 {g.cov95.median():.2f}, ρ_S {g.spearman_sd_vs_abs_log_err.median():.2f}", fontsize=7.5)
        ax.set_xlabel("GP predictive sd (model)"); ax.set_ylabel("held-out |log error| (MOOSE)") if c == 0 else None
        q = PR[(PR.surrogate == "A20") & (PR.n == 33) & (PR.method == m)]; ax = axs[1, c]; ax.scatter(q.meas_r, q.pred_r, s=2, color=MC[m], alpha=0.35, lw=0); ax.plot([5, 17], [5, 17], color=INK, lw=0.8)
        ax.set_xlabel("measured MOOSE r [MPa]"); ax.set_ylabel("predicted r [MPa]") if c == 0 else None
    fig.suptitle("n = 33: predicted uncertainty vs actual held-out error (top) and predicted vs measured radii (bottom), 9 starts pooled", x=0.01, ha="left", fontsize=9.5)
    save(fig, "X09_calibration_predicted_vs_measured")


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    convergence(); reconstructions(); selections(); acquisition_maps(); paired(); regional(); cpu(); risk_compare(); calibration()
    print(sorted({p.stem for p in FIG.iterdir()}))

#!/usr/bin/env python3
"""Independent integrity audit of the V3 transfer extension (writes only audit/ and MANIFEST.sha256).   python -B audit_v3x.py
Do NOT redirect this script's stdout into this directory (the manifest is computed here; campaign3's stdout-log race is avoided)."""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, subprocess, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE)); import v3x_common as X
C3 = X.C3; A = {}; (HERE / "audit").mkdir(exist_ok=True); PS = C3.CL.parent; V3D = C3.CL / "response_adaptive_v3_2026"
A["protocol_freeze_rc"] = subprocess.run(["sha256sum", "--quiet", "-c", "PROTOCOL.sha256"], cwd=HERE, capture_output=True).returncode
recs = {}
for l in (HERE / "trials/index.jsonl").read_text().splitlines():
    x = json.loads(l); recs[x["keyhash"]] = json.loads((HERE / x["record"]).read_text())
frozen_t = time.mktime(time.strptime((HERE / "FROZEN_AT.txt").read_text().strip()[:19], "%Y-%m-%dT%H:%M:%S"))
A["frozen_before_first_trial"] = dict(ok=bool(frozen_t < min((HERE / "trials/records" / f"{k}.json").stat().st_mtime for k in recs)))
c3m = subprocess.run(["sha256sum", "--quiet", "-c", "MANIFEST.sha256"], cwd=X.C3D, capture_output=True, text=True)
c3fail = [l.split(":")[0] for l in c3m.stdout.splitlines() if l.endswith("FAILED")]
A["untouched"] = dict(v3_protocol_files=all(C3.sha(V3D / f) == h for h, f in [l.split() for l in open(V3D / "PROTOCOL.sha256")]),
                      h1_protocol_rc=subprocess.run(["sha256sum", "--quiet", "-c", "PROTOCOL.sha256"], cwd=V3D / "holdout_h1_2026", capture_output=True).returncode,
                      campaign3_manifest_failures=c3fail, campaign3_only_known_exception=c3fail in ([], ["audit/audit_stdout_final.txt"]), v2_v1=bool(X.W.check_frozen()))
lib = X.library(); D = lib.directions; comp = {}
def rec_for(k):
    if k in recs:
        return recs[k], "own"
    hit = X._lookup(X.C3D / "trials/index.jsonl", X.C3D, k); return (hit[0], "campaign3") if hit else (None, None)
src_count = {"own": 0, "campaign3": 0}
for arm in X.ARMS:
    for s in X.STARTS:
        d = json.load(open(HERE / f"runs/{arm}/s{s}/design.json")); ri = json.load(open(HERE / f"runs/{arm}/s{s}/run_info.json")); ok = True
        for a, k, r in zip(d["axes"], d["keyhashes"], d["radii"]):
            rr, src = rec_for(k); ok &= bool(rr is not None and rr["valid"] and rr["oracle_id"] == X.ORACLE_ID and rr["yield_radius"] == r and C3.keyhash(D[a] / np.linalg.norm(D[a])) == k)
            src_count[src] = src_count.get(src, 0) + 1
        st = pd.read_csv(HERE / f"runs/{arm}/s{s}/steps.csv"); st = st[st.n_real.notna()]
        comp[f"{arm}_s{s}"] = dict(n=len(d["axes"]), unique=len(set(d["axes"])) == 64, init_ok=d["axes"][:8] == X.initial_design(lib, s), records_ok=ok,
                                   no_pseudo=bool((st.n_training_points == st.n_real).all()), version=ri["version"], failed=len(d["failed"]))
A["campaigns"] = dict(n=len(comp), all_ok=all(x["n"] == 64 and x["unique"] and x["init_ok"] and x["records_ok"] and x["no_pseudo"] for x in comp.values()),
                      versions=sorted({x["version"] for x in comp.values()}), failed=sum(x["failed"] for x in comp.values()), observation_sources=src_count)
A["new_trials"] = dict(n=len(recs), valid=sum(r["valid"] for r in recs.values()), max_equilibrium=max(r["equilibrium_rel_err_max"] for r in recs.values()),
                       max_periodic=max(r["periodic_check"]["rel"] for r in recs.values()), failed_steps=sum(r["failed_steps"] for r in recs.values()))
ref = pd.read_csv(C3.TREF_CSV); P = ref[["z1", "z2", "z3"]].to_numpy()
used = np.unique(np.concatenate([json.load(open(HERE / f"runs/{a}/s{s}/design.json"))["axes"] for a in X.ARMS for s in X.STARTS]))
A["leakage"] = dict(min_angle_obs_to_reference_deg=float(np.degrees(np.arccos(np.clip((D[used] @ P.T).max(), -1, 1)))), ref_keys_in_own_store=len({C3.keyhash(p) for p in P} & set(recs)))
def no_moose(*a, **k):
    raise RuntimeError("audit replay attempted a MOOSE run")
X.TO.observe = no_moose; rep = {}
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    for arm in X.ARMS:
        for s in (0, 4):
            r = X.controller(arm, lib, X.XOracle(f"AUDIT_{arm}_s{s}")).run(s); sc = np.load(HERE / f"runs/{arm}/s{s}/scores_f32.npy")
            mine = np.array([np.where(np.isfinite(x), x, np.nan) for x in r["scores"]], np.float32)
            rep[f"{arm}_s{s}"] = bool(r["sequence"] == json.load(open(HERE / f"runs/{arm}/s{s}/design.json"))["axes"] and np.array_equal(mine, sc, equal_nan=True))
A["replay_bitwise_from_stores"] = rep
cc = json.loads((HERE / "evaluation/comparator_consistency.json").read_text()); RW = pd.read_csv(HERE / "evaluation/risk_weighting.csv")
# comparator check on the WRITTEN files (text rows): the evaluator's in-memory flag compares full-precision floats with a CSV parsed by pandas'
# default (non-round-trip) float parser and reports a spurious 2.2e-16 difference; the written rows themselves must be byte-identical.
mine_rows = {l for l in (HERE / "evaluation/metrics.csv").read_text().splitlines()[1:] if l.split(",")[0] in ("V2", "AXMM", "RANDOM")}
c3_rows = set((X.C3D / "evaluation/metrics.csv").read_text().splitlines()[1:])
A["evaluation"] = dict(evaluator_flag_identical=cc["identical"], evaluator_flag_max_abs_dev=cc["max_abs_dev"], comparator_rows_byte_identical=bool(mine_rows == c3_rows and len(c3_rows) == 216),
                       risk_state_reconstruction_matches_choice=float(RW.chosen_matches_own_rule.mean()))
M = pd.read_csv(HERE / "evaluation/metrics.csv"); B = X.W.B; chk = []
for m, s in (("V3F", 2), ("V3S", 7)):
    d = json.load(open(HERE / f"runs/{m}/s{s}/design.json")); Xd = np.array(d["directions"]); r = np.array(d["radii"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"]).fit(Xd[:33], r[:33])
    Aset = (ref.set == "area").to_numpy(); e = np.abs(g.predict_radius(P[Aset]) / ref.yield_radius.to_numpy()[Aset] - 1).mean()
    v = M[(M.method == m) & (M.start == s) & (M.n == 33) & (M.surrogate == "A20")].area_mean.iloc[0]; chk.append(dict(cell=f"{m}_s{s}", rel=float(abs(e / v - 1))))
A["evaluation"]["recompute"] = chk
led = [json.loads(l) for l in (HERE / "cpu_ledger.jsonl").read_text().splitlines()]
A["ledger"] = dict(extension_total_cpu_h=sum(x["cpu_s"] for x in led) / 3600, moose_cpu_h=sum(x["cpu_s"] for x in led if x["item"].startswith("moose:")) / 3600,
                   sum_new_record_cpu_h=sum(r["cpu_s"] for r in recs.values()) / 3600, cap_cpu_h=4.0,
                   campaign3_separate_cpu_h=sum(json.loads(l)["cpu_s"] for l in (X.C3D / "cpu_ledger.jsonl").read_text().splitlines()) / 3600)
A["ledger"]["within_cap"] = A["ledger"]["extension_total_cpu_h"] <= 4.0
f = subprocess.run(["find", str(PS), "-newer", str(HERE / "FROZEN_AT.txt"), "-type", "f", "-not", "-path", f"{C3.T}/*"], capture_output=True, text=True).stdout.split(); grp = {}
for p in f:
    k = "/".join(Path(p).relative_to(PS).parts[:2]); grp[k] = grp.get(k, 0) + 1
A["outside_changes_since_freeze"] = grp
A["PASS"] = bool(A["protocol_freeze_rc"] == 0 and A["frozen_before_first_trial"]["ok"] and A["untouched"]["v3_protocol_files"] and A["untouched"]["h1_protocol_rc"] == 0
                 and A["untouched"]["campaign3_only_known_exception"] and A["campaigns"]["all_ok"] and A["leakage"]["ref_keys_in_own_store"] == 0
                 and all(rep.values()) and A["evaluation"]["comparator_rows_byte_identical"] and A["evaluation"]["risk_state_reconstruction_matches_choice"] == 1.0
                 and all(x["rel"] < 1e-12 for x in chk) and A["ledger"]["within_cap"])
(HERE / "audit/audit_v3x.json").write_text(json.dumps(A, indent=1, default=float))
rows = [f"{C3.sha(p)}  {p.relative_to(HERE)}" for p in sorted(HERE.rglob("*")) if p.is_file() and ".jitcache" not in p.parts and p.name != "MANIFEST.sha256" and not p.name.startswith(".")]
(HERE / "MANIFEST.sha256").write_text("\n".join(rows) + "\n")
print(json.dumps({k: v for k, v in A.items()}, indent=1, default=float))

"""V3 physical transfer extension (v3transfer_20261120): shared infrastructure.  Frozen with PROTOCOL.md (PROTOCOL.sha256).

* Uses the frozen campaign3 definitions READ-ONLY (c3_common: oracle identity, signed key, validity rule, library, initial design).
* Own trial store trials/ (records + compact index), own request log, own CPU ledger with an INCREMENTAL 4 CPU-h HARD CAP for this extension
  (campaign3's 3.24 CPU-h is reconciled separately and never read into this ledger's total).
* Exact-match reuse: own store first, then the FROZEN campaign3 store (read-only; same ORACLE_ID and signed key required).  Reused campaign3
  records are referenced, never copied into or written back to campaign3.  TREF references are never in either store.
* Guard: any *-opt process whose cwd is not inside this extension's trials/ stops new launches (campaign3 is finished).
* Nothing is deleted or overwritten.
"""
import fcntl, json, os, sys, time
from contextlib import contextmanager
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent; FC = HERE.parent; C3D = FC / "campaign3_20261120"
sys.dont_write_bytecode = True
for p in (str(C3D), str(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)
import c3_common as C3                                                               # frozen campaign3 definitions (read-only use)
import v3s_lrv as V3S                                                                # V3-Signed (this extension)
V3 = V3S.V3                                                                          # frozen V3 (read-only)
W = C3.W; TO = C3.TO; ORACLE_ID = C3.ORACLE_ID; keyhash = C3.keyhash; valid = C3.valid; library = C3.library; initial_design = C3.initial_design
TRIALS = HERE / "trials"; INDEX = TRIALS / "index.jsonl"; LEDGER = HERE / "cpu_ledger.jsonl"
CAP_CPU_S = 4 * 3600.0; EVAL_RESERVE_S = 0.30 * 3600.0; INFLIGHT_S = 15.0
STARTS = C3.STARTS; BUDGET = 64; N_INIT = 8; CHECKPOINTS = (8, 16, 33, 64)
ARMS = ("V3F", "V3S")                                                                # V3F = frozen V3 (transfer test), V3S = V3-Signed (exploratory)
COMPARATORS = ("V2", "AXMM", "RANDOM")                                               # frozen campaign3 results


class CapReached(RuntimeError):
    pass


class ForeignMoose(RuntimeError):
    pass


class NumericalInvalid(RuntimeError):
    pass


@contextmanager
def locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield fh
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def ledger_add(item, cpu_s, **kw):
    with locked(HERE / ".ledger.lock"):
        with open(LEDGER, "a") as f:
            f.write(json.dumps(dict(time=time.strftime("%Y-%m-%dT%H:%M:%S"), pid=os.getpid(), item=item, cpu_s=float(cpu_s), **kw)) + "\n")


def ledger_total():
    return sum(json.loads(l)["cpu_s"] for l in LEDGER.read_text().splitlines() if l.strip()) if LEDGER.exists() else 0.0


def foreign_moose():
    out = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            cmd = open(f"/proc/{pid}/cmdline", "rb").read().split(b"\0")
            if not cmd or not cmd[0].endswith(b"-opt"):
                continue
            cwd = os.readlink(f"/proc/{pid}/cwd")
        except OSError:
            continue
        if not cwd.startswith(str(TRIALS)):
            out.append((pid, cwd))
    return out


def _lookup(index, base, k):
    if not index.exists():
        return None
    for l in index.read_text().splitlines():
        x = json.loads(l)
        if x["keyhash"] == k:
            return json.loads((base / x["record"]).read_text()), str((base / x["record"]).relative_to(FC))
    return None


def lookup(d):
    """own store first, then the frozen campaign3 store (read-only).  returns (record, source) or None."""
    k = keyhash(d)
    with locked(TRIALS / ".index.lock"):
        hit = _lookup(INDEX, HERE, k)
    if hit is None:
        hit = _lookup(C3D / "trials/index.jsonl", C3D, k)                            # campaign3 is complete; read-only
    if hit is not None and hit[0].get("oracle_id") != ORACLE_ID:
        raise RuntimeError("oracle identity mismatch on reuse")
    return hit


def get(d, requester):
    d = np.asarray(d, float) / np.linalg.norm(d); k = keyhash(d)
    with locked(TRIALS / "locks" / f"{k}.lock"):
        hit = lookup(d); reused = hit is not None; src = hit[1] if hit else None
        if hit is None:
            if foreign_moose():
                raise ForeignMoose(str(foreign_moose()[:3]))
            if ledger_total() + INFLIGHT_S * 9 + EVAL_RESERVE_S > CAP_CPU_S:
                raise CapReached(f"ledger {ledger_total() / 3600:.3f} CPU-h")
            wd = TRIALS / k
            if wd.exists():
                wd = TRIALS / f"{k}_retry{int(time.time())}"
            try:
                rec = TO.observe(d, wd, C3.CAL)
            except Exception as e:
                rec = dict(direction=list(d), accepted=False, reason=repr(e), cpu_s=0.0, wall_s=0.0, flags=["exception"])
            rec.update(keyhash=k, key=[float(x) for x in C3.key(d)], oracle_id=ORACLE_ID, workdir=str(wd.relative_to(HERE)), first_requester=requester)
            rec["valid"] = valid(rec) if rec.get("accepted") else False
            rf = TRIALS / "records" / f"{k}.json"
            if rf.exists():
                rf = TRIALS / "records" / f"{k}_retry{int(time.time())}.json"
            rf.parent.mkdir(parents=True, exist_ok=True); rf.write_text(json.dumps(rec, indent=1, default=float))
            ledger_add(f"moose:{k}", rec.get("cpu_s", 0.0), requester=requester)
            with locked(TRIALS / ".index.lock"):
                with open(INDEX, "a") as f:
                    f.write(json.dumps(dict(keyhash=k, record=str(rf.relative_to(HERE)), accepted=bool(rec.get("accepted")), valid=rec["valid"])) + "\n")
            r = rec; src = "new"
        else:
            r = hit[0]
    with locked(HERE / ".requests.lock"):
        with open(HERE / "requests.jsonl", "a") as f:
            f.write(json.dumps(dict(time=time.time(), requester=requester, keyhash=k, reused=reused, source=src, accepted=bool(r.get("accepted")),
                                    valid=bool(r.get("valid")), yield_radius=r.get("yield_radius"))) + "\n")
    if r.get("accepted") and not r.get("valid"):
        raise NumericalInvalid(k)
    return r


class XOracle(C3.C3Oracle):
    """same blind adapter as campaign3 (public observation only), backed by this extension's get()."""

    def evaluate(self, d):
        self.calls += 1; return self._obs(d, get(d, self.requester))


def controller(arm, lib, oracle, budget=BUDGET, record_scores=True):
    st = W.V2Settings(symmetry="none", schedule="A20", budget=budget, record_scores=record_scores)
    return (V3.V3Controller if arm == "V3F" else V3S.V3SController)(lib, oracle, st)

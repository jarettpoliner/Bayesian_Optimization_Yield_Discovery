#!/usr/bin/env python3
"""EVALUATOR of the V3 transfer extension (frozen with PROTOCOL.md).  The only code here that reads TREF.   python -B evaluate_v3x.py
Uses the campaign3 evaluator functions READ-ONLY and unchanged (task, regions, signed_rank_exact incl. its Amendment 1), so the reconstruction GP,
metrics and regions are identical to the completed comparison.  All five methods are evaluated by the same code; the three campaign3 comparators
must reproduce campaign3's frozen metrics.csv exactly (consistency check, reported).
Outputs: evaluation/{metrics.csv, predictions.csv, comparator_consistency.json, paired.csv, claims.json, cost.csv, risk_weighting.csv,
risk_weighting_summary.json, response_ablation_selection.json}"""
import os, sys
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[v] = "1"
sys.dont_write_bytecode = True
import json, time, warnings, resource
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; sys.path.insert(0, str(HERE))
import v3x_common as X
sys.path.insert(0, str(X.C3D)); import evaluate_c3 as E                               # campaign3 evaluator (read-only; amended version)
OUT = HERE / "evaluation"; B = X.W.B; METHODS = ("V3F", "V3S", "V2", "AXMM", "RANDOM")
CONFIRMATORY = [("V3F", "AXMM"), ("V3F", "V2")]                                      # Arm A transfer test, Holm over these 2
EXPLORATORY = [("V3S", "AXMM"), ("V3S", "V2")]                                       # Arm B (amendment), Holm over these 2, labelled exploratory
SECONDARY = [("V3F", "AXMM"), ("V3F", "V2"), ("V3F", "RANDOM"), ("V3S", "AXMM"), ("V3S", "V2"), ("V3S", "RANDOM"), ("V3S", "V3F")]   # Holm over 7 per family
METRICS = ("area_mean", "area_rms", "area_p95", "area_max", "sweep_mean", "sweep_max", "cusp_mean", "cusp_max", "trans_mean", "trans_max", "nonfeature_mean",
           "cov90", "cov95")


def run_dir(m, s):
    return (HERE / "runs" / m / f"s{s}") if m in X.ARMS else (X.C3D / "runs" / m / f"s{s}")


def designs():
    out = {}
    for m in METHODS:
        for s in X.STARTS:
            d = json.load(open(run_dir(m, s) / "design.json")); out[(m, s)] = (np.array(d["directions"]), np.array(d["radii"]), d["keyhashes"])
    return out


def holm(ps):
    ps = np.asarray(ps, float); o = np.argsort(ps); adj = np.empty(len(ps)); run = 0.0
    for rank, i in enumerate(o):
        run = max(run, min(1.0, (len(ps) - rank) * ps[i])); adj[i] = run
    return adj


def pair_stats(M, sur, n, met, a, b):
    g = M[(M.surrogate == sur) & (M.n == n)]; ea = g[g.method == a].set_index("start")[met].loc[list(X.STARTS)]; eb = g[g.method == b].set_index("start")[met].loc[list(X.STARTS)]
    if met.startswith("cov"):                                                         # coverage: report |cov - nominal| ratio is not meaningful; difference only
        return dict(surrogate=sur, n=n, metric=met, a=a, b=b, median_a=float(ea.median()), median_b=float(eb.median()))
    L = np.log(eb.to_numpy() / ea.to_numpy()); st = E.signed_rank_exact(L)
    return dict(surrogate=sur, n=n, metric=met, a=a, b=b, wins_a=int((L > 0).sum()), ratio_HL=float(np.exp(st["HL"])), ratio_ci_lo=float(np.exp(st["ci_lo"])),
                ratio_ci_hi=float(np.exp(st["ci_hi"])), ci_conf=st["ci_conf"], p_exact=st["p_exact"], median_err_a=float(ea.median()), median_err_b=float(eb.median()),
                median_diff_pp=float(np.median(eb.to_numpy() - ea.to_numpy()) * 100))


def paired(M):
    rows = []
    for sur in ("A20", "FIXED"):
        for n in X.CHECKPOINTS:
            for met in METRICS:
                fam = [pair_stats(M, sur, n, met, a, b) for a, b in SECONDARY]
                if not met.startswith("cov"):
                    for x, q in zip(fam, holm([x["p_exact"] for x in fam])):
                        x["p_holm7"] = float(q)
                rows += fam
    return pd.DataFrame(rows)


def claims(M):
    out = {}
    for label, fam in (("CONFIRMATORY_arm_A_frozen_V3", CONFIRMATORY), ("EXPLORATORY_arm_B_V3_signed", EXPLORATORY)):
        prim = [pair_stats(M, "A20", 33, "area_mean", a, b) for a, b in fam]; adj = holm([x["p_exact"] for x in prim]); out[label] = {}
        for x, q in zip(prim, adj):
            fx = pair_stats(M, "FIXED", 33, "area_mean", x["a"], x["b"])
            better = dict(holm=q < 0.05, ci=x["ratio_ci_lo"] > 1, wins=x["wins_a"] >= 8, floor=x["median_diff_pp"] > E.DELTA_NUM_PP, fixed=(fx["wins_a"] >= 7 and fx["ratio_HL"] > 1))
            worse = dict(holm=q < 0.05, ci=x["ratio_ci_hi"] < 1, wins=(9 - x["wins_a"]) >= 8, floor=-x["median_diff_pp"] > E.DELTA_NUM_PP, fixed=((9 - fx["wins_a"]) >= 7 and fx["ratio_HL"] < 1))
            v = f"{x['a']} ADVANTAGE" if all(better.values()) else f"{x['a']} DISADVANTAGE" if all(worse.values()) else "NO SUPPORTED DIFFERENCE"
            out[label][f"{x['a']}_vs_{x['b']}"] = dict(primary=dict(x, p_holm2=float(q)), fixed=fx, criteria_better=better, criteria_worse=worse, verdict=v,
                                                       practically_meaningful=bool(v.endswith("ADVANTAGE") and "DIS" not in v and x["ratio_HL"] >= 1.10))
    return out


def cost(des):
    rows = []
    for (m, s), (_, _, keys) in des.items():
        recs = []
        for k in keys:
            hit = X._lookup(X.INDEX, HERE, k) or X._lookup(X.C3D / "trials/index.jsonl", X.C3D, k); recs.append(hit[0]["cpu_s"])
        info = json.load(open(run_dir(m, s) / "run_info.json")); per = info["controller_cpu_s"] / (X.BUDGET - X.N_INIT); cum = np.cumsum(recs)
        for n in X.CHECKPOINTS:
            rows.append(dict(method=m, start=s, n=n, moose_cpu_h=cum[n - 1] / 3600, controller_cpu_h=per * max(0, n - 8) / 3600, total_cpu_h=(cum[n - 1] + per * max(0, n - 8)) / 3600))
    return pd.DataFrame(rows)


def risk_weighting(des, lib):
    """output 8: at every GP state of every V3F and V3S campaign (n = 8..63), the frozen (antipodal) and signed LOO-risk fields and their argmax."""
    D = lib.directions; N = len(D); anti = np.r_[np.arange(N // 2, N), np.arange(N // 2)]; rows = []
    for arm in X.ARMS:
        for s in X.STARTS:
            d = json.load(open(run_dir(arm, s) / "design.json")); ax = d["axes"]; r = np.array(d["radii"]); st = pd.read_csv(run_dir(arm, s) / "steps.csv")
            for n in range(8, 64):
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore"); g = B.GPv2(B.NO_SYMMETRY, B.SCHEDULES["A20"], held=None).fit(D[ax[:n]], r[:n])
                if g.mode_ == "held":
                    continue
                _, var = g.predict_log(D); u = X.V3.loo_standardised(g); rf, _ = X.V3.risk(g, D, u); rs, _ = X.V3S.risk_signed(g, D, u)
                a1 = var * rf; a2 = var * rs; a1[ax[:n]] = -np.inf; a2[ax[:n]] = -np.inf; m2 = var.copy(); m2[ax[:n]] = -np.inf
                sel = lambda a: int(X.V3.select(a, "deterministic", 1e-10, 1e-12)[0])       # frozen tie rule
                jf, js, jm = sel(a1), sel(a2), sel(m2)
                rows.append(dict(arm=arm, start=s, n=n, chosen=int(ax[n]), argmax_frozen=jf, argmax_signed=js, argmax_mes=jm, frozen_ne_signed=jf != js,
                                 chosen_matches_own_rule=(int(ax[n]) == (jf if arm == "V3F" else js)), corr_rho=float(np.corrcoef(np.log(rf), np.log(rs))[0, 1]),
                                 rho_frozen_at_antipodes_of_obs=float(np.mean(rf[anti[ax[:n]]])), rho_signed_at_antipodes_of_obs=float(np.mean(rs[anti[ax[:n]]])),
                                 u_rms=float(np.sqrt(np.mean(u ** 2))), max_abs_u=float(np.abs(u).max())))
    return pd.DataFrame(rows)


def response_ablation(lib):
    """descriptive: both V3 arms driven by ISOTROPIC von Mises radii (no information about TL1; no MOOSE): selection overlap with the actual designs."""
    from yield_surface_discovery.oracle import YieldOracle, YieldObservation
    class Iso(YieldOracle):
        def evaluate(self, d):
            d = np.asarray(d, float); vm = np.sqrt(d[0] ** 2 + d[1] ** 2 - d[0] * d[1] + 1.5 * d[2] ** 2)
            return YieldObservation(requested_direction=d, achieved_direction=d, stress_at_yield=d / vm, yield_radius=float(10.0 / vm))
        def evaluate_many(self, X_):
            return [self.evaluate(x) for x in np.atleast_2d(X_)]
    out = {}
    for arm in X.ARMS:
        for s in X.STARTS:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore"); iso = X.controller(arm, lib, Iso(), record_scores=False).run(s)["sequence"]
            act = json.load(open(run_dir(arm, s) / "design.json"))["axes"]; v2 = json.load(open(run_dir("V2", s) / "design.json"))["axes"]
            out[f"{arm}_s{s}"] = dict(first_divergence_iso=next((i + 1 for i, (a, b) in enumerate(zip(act, iso)) if a != b), None), overlap33_iso=len(set(act[:33]) & set(iso[:33])),
                                      overlap64_iso=len(set(act) & set(iso)), overlap33_v2=len(set(act[:33]) & set(v2[:33])), overlap64_v2=len(set(act) & set(v2)))
    return out


if __name__ == "__main__":
    import multiprocessing as mp
    OUT.mkdir(exist_ok=True); t0 = time.process_time(); rc0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    ref = pd.read_csv(X.C3.TREF_CSV); tab = pd.read_csv(X.C3.T / "pilot/tl1_reference_table.csv").set_index("ref_id").loc[ref.ref_id].reset_index()
    for f in ("FH", "FI60", "FI120", "K0", "K60", "K120"):
        ref[f"share_{f}"] = tab[f"share_{f}"].to_numpy()
    cusp, trans = E.regions(ref); des = designs(); lib = X.library()
    with mp.Pool(8) as p:
        res = p.map(E.task, [(k, v, ref, cusp, trans) for k, v in des.items()])
    M = pd.DataFrame([r for rr, _ in res for r in rr]); Pr = pd.DataFrame([q for _, pp in res for q in pp])
    M.to_csv(OUT / "metrics.csv", index=False); Pr.to_csv(OUT / "predictions.csv", index=False)
    c3 = pd.read_csv(X.C3D / "evaluation/metrics.csv"); mine = M[M.method.isin(["V2", "AXMM", "RANDOM"])]
    key = ["method", "start", "surrogate", "n"]; j = mine.merge(c3, on=key, suffixes=("", "_c3")); num = [c for c in c3.columns if c not in key and c != "gp_mode"]
    dev = float(max(np.nanmax(np.abs(j[c] - j[c + "_c3"])) for c in num))
    (OUT / "comparator_consistency.json").write_text(json.dumps(dict(rows=len(j), expected=len(c3), max_abs_dev=dev, identical=bool(len(j) == len(c3) and dev == 0.0)), indent=1))
    PD = paired(M); PD.to_csv(OUT / "paired.csv", index=False); CL = claims(M); (OUT / "claims.json").write_text(json.dumps(CL, indent=1, default=float))
    cost(des).to_csv(OUT / "cost.csv", index=False)
    RW = risk_weighting(des, lib); RW.to_csv(OUT / "risk_weighting.csv", index=False)
    (OUT / "risk_weighting_summary.json").write_text(json.dumps(dict(
        share_frozen_ne_signed={a: float(RW[RW.arm == a].frozen_ne_signed.mean()) for a in X.ARMS},
        chosen_matches_own_rule={a: float(RW[RW.arm == a].chosen_matches_own_rule.mean()) for a in X.ARMS},
        median_corr_log_rho={a: float(RW[RW.arm == a].corr_rho.median()) for a in X.ARMS}, n_states=len(RW)), indent=1))
    (OUT / "response_ablation_selection.json").write_text(json.dumps(response_ablation(lib), indent=1))
    (OUT / "regions.json").write_text(json.dumps(dict(n_cusp=int(cusp.sum()), n_transition=int(trans.sum())), indent=1))
    rc1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    X.ledger_add("evaluation", time.process_time() - t0 + (rc1.ru_utime - rc0.ru_utime) + (rc1.ru_stime - rc0.ru_stime))
    print(json.dumps({k: {kk: vv["verdict"] for kk, vv in v.items()} for k, v in CL.items()}))
    print(M[M.surrogate == "A20"].groupby(["n", "method"]).area_mean.median().unstack("method").mul(100).round(3).to_string())
